package com.capg.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

@Entity
public class Address {
	@Id
	private int addressid;
	private String address;
	@OneToOne
	@JoinColumn(name="custfk")
	private Customer customer;
	
	public Address() {
		super();
	}
	public Address(int addressid, String address, Customer customer) {
		super();
		this.addressid = addressid;
		this.address = address;
		this.customer = customer;
	}
	public int getAddressid() {
		return addressid;
	}
	public void setAddressid(int addressid) {
		this.addressid = addressid;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public Customer getCustomer() {
		return customer;
	}
	public void setCustomer(Customer customer) {
		this.customer = customer;
	}
	@Override
	public String toString() {
		return "Address [addressid=" + addressid + ", address=" + address + ", customer=" + customer + "]";
	}
	

}
