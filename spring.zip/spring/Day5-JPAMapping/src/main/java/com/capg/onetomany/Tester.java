package com.capg.onetomany;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;



public class Tester {

	public static void main(String[] args) {
		
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("jpademo");
		EntityManager entityManager=emf.createEntityManager();
		EntityTransaction transaction=entityManager.getTransaction();
		transaction.begin();
		Company tcs=new Company("TCS");
		Company wipro=new Company("Wipro");
		Employee emp1=new Employee("Sri",tcs);
		Employee emp2=new Employee("Sai",tcs);
		Employee emp3=new Employee("Krishna",wipro);
		Employee emp4=new Employee("Tom",wipro);
		
		entityManager.persist(tcs);
		entityManager.persist(wipro);
		entityManager.persist(emp1);
		entityManager.persist(emp2);
		entityManager.persist(emp3);
		entityManager.persist(emp4);
		
		transaction.commit();
		entityManager.close();

	}

}
