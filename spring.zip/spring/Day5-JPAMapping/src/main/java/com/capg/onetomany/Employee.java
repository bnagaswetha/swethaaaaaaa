package com.capg.onetomany;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity
public class Employee {
	@Id
	@GeneratedValue
	private int employeeid;
	private String employeeName;
	@ManyToOne
	@JoinColumn(name="capFk")
	private Company company;
	public Employee() {
		super();
	}

	
	public Employee(String employeeName, Company company) {
		super();
		this.employeeName = employeeName;
		this.company = company;
	}


	public int getEmployeeid() {
		return employeeid;
	}
	public void setEmployeeid(int employeeid) {
		this.employeeid = employeeid;
	}
	public String getEmployeeName() {
		return employeeName;
	}
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}
	public Company getCompany() {
		return company;
	}
	public void setCompany(Company company) {
		this.company = company;
	}
	@Override
	public String toString() {
		return "Employee [employeeid=" + employeeid + ", employeeName=" + employeeName + ", company=" + company + "]";
	}
	
	
	
	
	

}
