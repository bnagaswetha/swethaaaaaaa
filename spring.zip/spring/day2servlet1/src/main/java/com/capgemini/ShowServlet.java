package com.capgemini;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class ShowServlet
 */
@WebServlet("/ShowServlet")
public class ShowServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		String msg=request.getParameter("msg");
		//HttpSession
		HttpSession session=request.getSession();
		session.setAttribute("user", "Tom");
		
		
		//cookies
		Cookie cookie1=new Cookie("fruit","banana");
		response.addCookie(cookie1);
		
		Cookie cookie2=new Cookie("fruits","apple");
		cookie2.setMaxAge(10);
		response.addCookie(cookie2);
		
		
		Cookie[] cookies=request.getCookies();
		if(cookies!=null) {
		for(Cookie cookie:cookies) {
			response.getWriter().println("Key->"+cookie.getName()+"<br>Value->"+cookie.getValue());
		}
		}
		response.getWriter().println("message:"+request.getParameter("msg"));
		//hidden form field
		response.getWriter().println("name:"+request.getParameter("name"));
		//url-rewriting
		response.getWriter().println("<a href='PrintServlet?msg="+msg+"'>Click to see your msg</a>");
	}

}
