package com.cap.demo;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
@Table(name="customerinfo")
@Entity
public class Customer {
	@Id
	private int customerid;
	private String customername;
	private Double regfees;
	private Date regdate;
	
	
	public Customer() {
		super();
	}


	public Customer(int customerid, String customername, Double regfees, Date regdate) {
		super();
		this.customerid = customerid;
		this.customername = customername;
		this.regfees = regfees;
		this.regdate = regdate;
	}


	public int getCustomerid() {
		return customerid;
	}


	public void setCustomerid(int customerid) {
		this.customerid = customerid;
	}


	public String getCustomername() {
		return customername;
	}


	public void setCustomername(String customername) {
		this.customername = customername;
	}


	public Double getRegfees() {
		return regfees;
	}


	public void setRegfees(Double regfees) {
		this.regfees = regfees;
	}


	public Date getRegdate() {
		return regdate;
	}


	public void setRegdate(Date regdate) {
		this.regdate = regdate;
	}
	

}
