package com.capgemini.services;

import javax.ws.rs.Path;

public class MyRestServices {
	
	@Path("/hello")
	public String sayHello() {
		return "Hello from REST";
		
		
	}

}
