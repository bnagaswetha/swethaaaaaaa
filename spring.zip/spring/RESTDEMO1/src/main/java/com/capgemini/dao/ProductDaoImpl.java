package com.capgemini.dao;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.capgemini.services.Product;

public class ProductDaoImpl implements IProductDao{
	
private static List<Product> products=dummyDB();
	
	

	private static List<Product> dummyDB() {
		List<Product> products=new ArrayList<Product>();
		products.add(new Product(1,"Apple XS"));
		products.add(new Product(2,"Samsung"));
		products.add(new Product(3,"Honor"));
		products.add(new Product(4,"Oppo"));
		return products;
	}




	public List<Product> getAllProducts() {
		
		return products;
	}




	public List<Product> deleteProduct(int productId) {
		Iterator<Product> iterator=products.iterator();
		while(iterator.hasNext()) {
			Product product=iterator.next();
			if(product.getProductId().equals(productId)) {
				iterator.remove();
				break;
				
			}
			
		}
		return products;
		
	}




	public List<Product> addProduct(Product product) {
		products.add(product);
		
		return products;
	}




	public Product findProduct(int productId) {
		Iterator<Product> iterator=products.iterator();
		while(iterator.hasNext()) {
			Product product=iterator.next();
			if(product.getProductId().equals(productId)) {
				return product;
				
			}
			
		}
		return null;
		
		
		
	}




	public List<Product> updateProduct(Product product) {
		Iterator<Product> iterator=products.iterator();
		while(iterator.hasNext()) {
			Product product1=iterator.next();
			if(product1.getProductId().equals(product.getProductId())) {
				products.remove(product1);
				
				products.add(product);
				
				
			}
		}
		
		return products;
	}

}
