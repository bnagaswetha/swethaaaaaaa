package com.capgemini.services;

import javax.ws.rs.GET;
import javax.ws.rs.Path;

@Path("/api")
public class MyRestServices {
	@GET
	@Path("/hello")
	public String sayHello() {
		return "Hello from REST";
		
		
	}

}
