package com.capgemini;

import javax.xml.ws.Endpoint;

public class SimpleInterestPublisher {
	public static void main(String[] args) {
		Endpoint.publish("http://localhost:7702/ws/si",new SimpleInterestImpl());

	}

}
