package com.capgemini;

import javax.jws.WebService;

@WebService(endpointInterface="com.capgemini.SimpleInterest")
public class SimpleInterestImpl implements SimpleInterest{

	@Override
	public Double calSimpleInterest(int p, int t, int r) {
		double c=(p*t*r)/100;
		return c;
	}
	

}
