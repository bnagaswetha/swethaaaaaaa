package org.cap.service;

import org.cap.dao.ILoginDao;
import org.cap.dao.LoginDaoImpl;
import org.cap.model.LoginBean;

public class LoginService implements ILoginService{
	private ILoginDao loginDao;
	public LoginService() {
		this.loginDao=new LoginDaoImpl();
	}

	@Override
	public boolean isValidLogin(LoginBean loginBean) {
		if(loginDao.isValidLogin(loginBean))
			return true;
		return false;
	}

}
