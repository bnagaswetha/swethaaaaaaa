package org.cap.demo;

import java.io.IOException;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.FormatStyle;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.SimpleTagSupport;

public class DateFormat extends SimpleTagSupport{
	private String format1;


	public void setFormat1(String format1) {
		this.format1 = format1;
	}


	@Override
	public void doTag() throws JspException, IOException {

		JspWriter out= getJspContext().getOut();
		LocalDate dt=LocalDate.now();
	
		DateTimeFormatter formatter=DateTimeFormatter.ofPattern(this.format1);
		String s1=formatter.format(dt);

		out.println(s1);

	}


}
