package com.capgemini.Product.service;

import java.util.List;

import com.capgemini.Product.Model.Product;

public interface IinventoryService {

	

	List<Product> saveProduct(Product product);

	List<Product> getAllProducts();

	List<Product> deleteProducts(Integer productId);

}
