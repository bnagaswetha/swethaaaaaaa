package com.capgemini.Product.Dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.capgemini.Product.Model.Customer;

@Repository("iCustomerDao")
@Transactional
public interface ICustomerDao extends JpaRepository<Customer, Integer>{

}
