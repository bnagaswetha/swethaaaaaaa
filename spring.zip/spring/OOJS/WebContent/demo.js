function employee(empid,empname,salary){
	var emp={};
	emp.empid=empid;
	emp.empname=empname;
	emp.salary=salary
	
	return emp;
}
var empobj=employee(1001,'Tom',7874);
console.log('EmployeeId:'+empobj.empid)
console.log('EmployeeName:'+empobj.empname)
console.log('Employeesal:'+empobj.salary)