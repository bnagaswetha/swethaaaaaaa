function customer(custid){
	var custid;
	var custName;
	
	this.getCustid=function(){
		alert('custid:'+custid)
		return custid;
	}

	this.setCustid=function(id){
		custid=id;
	}
	this.getCustname=function(){
		alert('custname:'+custName)
	}

	this.setCustname=function(name){
		custid=name;
	}
	
}



var custobj=new customer();
custobj.setCustid(1001);
console.log(custobj.getCustid());

