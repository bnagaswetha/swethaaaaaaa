var emps=[{
	"empid":1001,
	"empname":"Tom",
	"department":["sales","purchase"],
	"address":{
		"stname":"78 colony",
		"state":"AP"
	}
},
{
	"empid":1002,
	"empname":"Jack",
	"department":["sales","Finance"],
	"address":{
		"stname":"88 colony",
		"state":"TN"
	}
}]
console.log(emps)