function Employee(name){
	this.name=name;
}

Employee.prototype.getName=function(){
	return this.name;

}

function Department(name,manager){
	this.name=name;
	this.manager=manager;
}
Department.prototype.getDeptName=function(){
	return this.name;
}
Department.prototype.getDeptMgr=function(){
	return this.manager;
}

var emp=new Employee('Tom')
console.log(emp)
console.log(emp.getName())
var dept=new Department('Smith','AA')
console.log(dept)
console.log(dept.getDeptName())
/*dept._proto_=emp
console.log(dept)
console.log(dept._proto_.getName())
console.log(dept.getDeptMgr())*/
Department.prototype=new Employee('Jack')
var dept=new Department('sales','BB')

console.log(dept.getName())