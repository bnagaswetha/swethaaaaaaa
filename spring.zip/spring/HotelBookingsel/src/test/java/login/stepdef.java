package login;


import static org.junit.Assert.assertEquals;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import bean.BookingBean;
import bean.LoginBean;

import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class stepdef {
	private WebDriver driver;
	private BookingBean bookingBean;
	private LoginBean loginBean;
	
	
	@Before
	public void setUp() {
		System.setProperty("webdriver.chrome.driver","D:\\chrome\\chromedriver.exe");
		driver=new ChromeDriver();
		bookingBean=new BookingBean(driver);
		loginBean=new LoginBean(driver);
		
	}
	
	@Given("^Open HotelBooking Login page$")
	public void open_HotelBooking_Login_page() throws Throwable {
		driver.get("http://localhost:8081/HotelBookingsel/login.html");
		/*String head = driver.findElement(By.xpath("/html/body/div/h2")).getText();
		assertEquals("Hotel Booking Form",head);*/
	}

	@Given("^provide username$")
	public void provide_username() throws Throwable {
		loginBean.assignValues("","capg1234");
	}

	@When("^submit validate login details$")
	public void submit_validate_login_details() throws Throwable {
		loginBean.setSignBtn();
	}

	@Then("^give error message$")
	public void give_error_message() throws Throwable {
		String userErrorMsg=driver.findElement(By.xpath("//*[@id=\"userErrMsg\"]")).getText();
		System.out.println("Msg"+userErrorMsg);
		assertEquals("* Please enter userName.",userErrorMsg);
		Thread.sleep(1000);
	}

	@Given("^Open HotelBooking Login Page$")
	public void open_HotelBooking_Login_Page() throws Throwable {
		driver.get("http://localhost:8081/HotelBookingsel/login.html");
		/*String head = driver.findElement(By.xpath("/html/body/div/h2")).getText();
		assertEquals("Hotel Booking Form",head);*/
	}

	@Given("^provide username and password$")
	public void provide_username_and_password() throws Throwable {
		loginBean.assignValues("capgemini","");
	}

	@When("^submit validate logins$")
	public void submit_validate_logins() throws Throwable {
		loginBean.setSignBtn();
	}

	@Then("^give the error message$")
	public void give_the_error_message() throws Throwable {
		String userErrorMsg=driver.findElement(By.xpath("//*[@id=\"pwdErrMsg\"]")).getText();
		System.out.println("Msg"+userErrorMsg);
		assertEquals("* Please enter password.",userErrorMsg);
	}

	@Given("^Open HotelBooking login page$")
	public void open_HotelBooking_login_page() throws Throwable {
		driver.get("http://localhost:8081/HotelBookingsel/login.html");
		/*String head = driver.findElement(By.xpath("/html/body/div/h2")).getText();
		assertEquals("Hotel Booking Form",head);*/
	}

	@Given("^provide  valid username and password$")
	public void provide_valid_username_and_password() throws Throwable {
		loginBean.assignValues("capgemini","capg1234");
	}

	@When("^submit validate the  login$")
	public void submit_validate_the_login() throws Throwable {
		loginBean.setSignBtn();
	}

	@Then("^navigate to hotelbooking$")
	public void navigate_to_hotelbooking() throws Throwable {
		driver.navigate().to("http://localhost:8081/HotelBookingsel/pages/hotelbooking.html");
	}


	
	
}
