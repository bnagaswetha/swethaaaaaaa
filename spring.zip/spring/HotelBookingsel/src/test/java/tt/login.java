package tt;





	import static org.junit.Assert.assertEquals;

	import org.openqa.selenium.By;
	import org.openqa.selenium.WebDriver;
	import org.openqa.selenium.WebElement;
	import org.openqa.selenium.chrome.ChromeDriver;


	import cucumber.api.java.Before;
	import cucumber.api.java.en.Given;
	import cucumber.api.java.en.Then;
	import cucumber.api.java.en.When;

	public class login {
		
		private WebElement element;
		private WebDriver webdriver;

		@Before
		public void setUp() {
			System.setProperty("webdriver.chrome.driver","D:\\chrome\\chromedriver.exe");
			webdriver=new ChromeDriver();
		}
		@Given("^Open HotelBooking Login page$")
		public void open_HotelBooking_Login_page() throws Throwable {
			 webdriver.get("http://localhost:8081/HotelBookingsel/login.html");
			 String head=webdriver.findElement(By.xpath("//*[@id=\"mainCnt\"]/div/div[1]/h1")).getText();
			 assertEquals("Hotel Booking Application",head);
		}

		@Given("^provide username$")
		public void provide_username() throws Throwable {
			webdriver.findElement(By.name("userName")).sendKeys("");
		}

		@When("^submit validate login details$")
		public void submit_validate_login_details() throws Throwable {
			element=webdriver.findElement(By.className("btn"));
			element.click();;
		}

		@Then("^give error message$")
		public void give_error_message() throws Throwable {
			String msg=webdriver.findElement(By.id("userErrMsg")).getText();
			assertEquals("* Please enter userName.",msg);
			webdriver.findElement(By.className("btn")).click();
			Thread.sleep(5000);
			webdriver.navigate().to("http://localhost:8081/HotelBookingsel/login.html");
		}

		@Given("^Open HotelBooking Login Page$")
		public void open_HotelBooking_Login_Page() throws Throwable {
			 webdriver.get("http://localhost:8081/HotelBookingsel/login.html");
		}

		@Given("^provide username and password$")
		public void provide_username_and_password() throws Throwable {
			webdriver.findElement(By.name("userName")).sendKeys("capgemini");
			   webdriver.findElement(By.name("userPwd")).sendKeys("");
		}

		@When("^submit validate logins$")
		public void submit_validate_logins() throws Throwable {
			element=webdriver.findElement(By.className("btn"));
			element.click();
		}

		@Then("^give the error message$")
		public void give_the_error_message() throws Throwable {
			String msg=webdriver.findElement(By.id("pwdErrMsg")).getText();
			assertEquals("* Please enter password.",msg);
			webdriver.findElement(By.className("btn")).click();
			Thread.sleep(5000);
			webdriver.navigate().to("http://localhost:8081/HotelBookingsel/login.html");
		}

		@Given("^Open HotelBooking login page$")
		public void open_HotelBooking_login_page() throws Throwable {
			 webdriver.get("http://localhost:8081/HotelBookingsel/login.html");
		}

		@Given("^provide  valid username and password$")
		public void provide_valid_username_and_password() throws Throwable {
			webdriver.findElement(By.name("userName")).sendKeys("capgemini");
			   webdriver.findElement(By.name("userPwd")).sendKeys("capg1234");
		}

		@When("^submit validate the  login$")
		public void submit_validate_the_login() throws Throwable {
			element=webdriver.findElement(By.className("btn"));
			element.click();
		}

		@Then("^navigate to hotelbooking$")
		public void navigate_to_hotelbooking() throws Throwable {
			
			webdriver.navigate().to("http://localhost:8081/HotelBookingsel/pages/hotelbooking.html");
			assertEquals("Hotel Booking",webdriver.getTitle());
			
			webdriver.findElement(By.id("txtFirstName"));
			webdriver.findElement(By.id("btnPayment")).click();
		}



	}


