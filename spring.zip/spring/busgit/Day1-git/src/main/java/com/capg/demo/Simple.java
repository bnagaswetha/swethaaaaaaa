package com.capg.demo;

public class Simple {

	public static void main(String[] args) {
		System.out.println("Hello");
		print();

	}

	private static void print() {
		System.out.println("print method");
		System.out.println("print method11");
		System.out.println("print method57651");
	}

}
