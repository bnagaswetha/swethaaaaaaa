package org.cap.config;

import org.cap.model.Address;
import org.cap.model.CustomerBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;

@Configuration

public class JavaConfig {
	
	@Bean
	//@Scope("prototype")
	public CustomerBean getCustomer() {
		CustomerBean customer=new CustomerBean();
		customer.setCustId(10001);
		customer.setCustName("swetha");
		customer.setRegFee(4000);
		//customer.setAddress(getAddress());
		return customer;
	}
	
	
	@Bean
	public Address getAddress() {
		Address address=new Address();
		address.setCity("Chennai");
		address.setStreetName("NorthAveenue");
		return address;
		
	}
	
	/*@Bean
	public Address getAddress1() {
		Address address=new Address();
		address.setCity("Hyd");
		address.setStreetName("southAveenue");
		return address;
		
	}*/
	

}
