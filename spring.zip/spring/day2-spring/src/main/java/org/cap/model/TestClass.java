package org.cap.model;

import org.cap.config.JavaConfig;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestClass {

	public static void main(String[] args) {
		AbstractApplicationContext context=new AnnotationConfigApplicationContext(JavaConfig.class);
		CustomerBean customer=context.getBean(CustomerBean.class);
		CustomerBean customer1=context.getBean(CustomerBean.class);
		customer1.setCustName("Balu");
		System.out.println(customer1);
		System.out.println(customer);
		//context.registerShutdownHook();;
		
		
		context.close();
			
			
		

	}

}
