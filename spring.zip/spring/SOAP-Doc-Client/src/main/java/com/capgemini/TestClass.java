package com.capgemini;

import java.net.MalformedURLException;
import java.net.URL;

import javax.xml.namespace.QName;
import javax.xml.ws.Service;

public class TestClass {

	public static void main(String[] args) throws MalformedURLException {
		URL url=new URL("http://localhost:7702/ws/si?wsdl");
		QName qname=new QName("http://capgemini.com/","SimpleInterestImplService");
		
		Service service=Service.create(url,qname);
		SimpleInterest simpleinterest=service.getPort(SimpleInterest.class);
		System.out.println("Simple Interest: "+simpleinterest.calSimpleInterest(2000,2,5));
	}

}
