package org.cap.model;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestClass {

	public static void main(String[] args) {
		AbstractApplicationContext context=new ClassPathXmlApplicationContext("myBeans.xml");
		CustomerBean customer=(CustomerBean)context.getBean("customer");
		/*CustomerBean customer1=(CustomerBean)context.getBean("customer");
		customer1.setCustName("Balu");
		System.out.println(customer1);*/
		System.out.println(customer);
		context.registerShutdownHook();;
		
		
		//context.close();
			
			
		

	}

}
