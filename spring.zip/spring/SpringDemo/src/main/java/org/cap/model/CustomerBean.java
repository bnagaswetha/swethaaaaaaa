package org.cap.model;

public class CustomerBean {
	private int custId;
	private String custName;
	private double regFee;
	
	private Address address;
	
	public CustomerBean() {
		super();
	}



	public CustomerBean(int custId, String custName, double regFee,Address address ) {
		super();
		this.custId = custId;
		this.custName = custName;
		this.regFee = regFee;
		this.address=address;
	}



	public Address getAddress() {
		return address;
	}



	public void setAddress(Address address) {
		this.address = address;
	}



	public int getCustId() {
		return custId;
	}



	public void setCustId(int custId) {
		this.custId = custId;
	}



	public String getCustName() {
		return custName;
	}



	public void setCustName(String custName) {
		this.custName = custName;
	}



	public double getRegFee() {
		return regFee;
	}



	public void setRegFee(double regFee) {
		this.regFee = regFee;
	}



	@Override
	public String toString() {
		return "CustomerBean [custId=" + custId + ", custName=" + custName + ", regFee=" + regFee + ", address="
				+ address + "]";
	}

	public void init() {
		System.out.println("Bean Initialized");
	}
	public void destroy() {
		System.out.println("Bean destroyed");
	}

	

}
