package com.capgemini.hbms.service;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.List;

import com.capgemini.hbms.bean.BookingDetails;
import com.capgemini.hbms.dao.BookingDaoImpl;
import com.capgemini.hbms.dao.IBookingDao;
import com.capgemini.hbms.dao.IRoomDao;
import com.capgemini.hbms.dao.RoomDaoImpl;
import com.capgemini.hbms.exception.HBMSException;

public class BookingServiceImpl implements IBookingService{
	IRoomDao dao=new RoomDaoImpl();
	IBookingDao bookingDao=new BookingDaoImpl();
	@Override
	public Integer addBookingDetails(BookingDetails bookingDetails)
			throws HBMSException {
		
		
		return bookingDao.addBookingDetails(findAmount(bookingDetails));
	}
	private BookingDetails findAmount(BookingDetails bookingDetails) {
		Long days=ChronoUnit.DAYS.between(bookingDetails.getBooked_from(), bookingDetails.getBooked_to());
		try {
			Double price=dao.getPrice(bookingDetails.getRoom_id());
			Double amount=price*days;
			bookingDetails.setAmount(amount);
			return bookingDetails;
		} catch (HBMSException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	@Override
	public BookingDetails getBookingDetails(String email) throws HBMSException{
		
		return bookingDao.getBookingDetails(email);
	}
	@Override
	public List<BookingDetails> getBookingDetails(int hotel_id)
			throws HBMSException {
		return bookingDao.getBookingDetails(hotel_id);
	}
	@Override
	public List<BookingDetails> getBookingDetails(LocalDate fdate)
			throws HBMSException {
		return bookingDao.getBookingDetails(fdate);
	}
	

}
