package com.capgemini.hbms.dao;

import java.util.List;

import com.capgemini.hbms.bean.Room;
import com.capgemini.hbms.exception.HBMSException;

public interface IRoomDao {

	Boolean addRoomDetails(Room room) throws HBMSException;

	void deleteRoomDetails(Integer hotelId1, String roomNo1) throws HBMSException;

	List<Room> displayRoomDetails() throws HBMSException;

	List<Room> displayRoomDetails(int hotel_id) throws HBMSException;

	Double getPrice(Integer room_id) throws HBMSException;

	void updateRoomPrice(int room_id, Double price) throws HBMSException;

	void updateType(int roomid, String type) throws HBMSException;

	
}
