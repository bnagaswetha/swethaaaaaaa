package com.capgemini.hbms.ui;

import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import org.apache.log4j.Logger;

import com.capgemini.hbms.bean.BookingDetails;
import com.capgemini.hbms.bean.Hotel;
import com.capgemini.hbms.bean.Room;
import com.capgemini.hbms.exception.HBMSException;
import com.capgemini.hbms.service.BookingServiceImpl;
import com.capgemini.hbms.service.HotelServiceImpl;
import com.capgemini.hbms.service.IBookingService;
import com.capgemini.hbms.service.IHotelService;
import com.capgemini.hbms.service.IRoomService;
import com.capgemini.hbms.service.IUserLoginService;
import com.capgemini.hbms.service.RoomServiceImpl;
import com.capgemini.hbms.service.UserLoginServiceImpl;

public class AdminScreen {
	public static IUserLoginService userService=new UserLoginServiceImpl();
	public static IHotelService hotelService=new HotelServiceImpl();
	static IRoomService roomService = new RoomServiceImpl();
	static IBookingService bookingService = new BookingServiceImpl();
	private static Logger myUILogger=Logger.getLogger(AdminScreen.class);
	
	public static Scanner sc=new Scanner(System.in);
	public  boolean checkValidAdmin() {
		System.out.println("Enter your email");
		String email=sc.next();
		System.out.println("Enter your password");
		String password=sc.next();
		try {
			if(userService.checkValidAdmin(email, password)){
				//System.out.println("you are valid user ");
				
				return true;
			}
			else{
				System.out.println("you are invalid user");
				
				return false;
			}
		} catch (HBMSException e) {
			myUILogger.info(e.getMessage());
			System.out.println("please enter valid details");
			//e.printStackTrace();
		}
		
		return false;
	}
	public Boolean addHotelDetails() {
		
		System.out.println("Enter Hotel Id");
		Integer hotelId = sc.nextInt();
		System.out.println("Enter amount per night");
		double avgRatePerNight = sc.nextDouble();
		System.out.println("Enter City");
		String city = sc.next();
		sc.nextLine();
		System.out.println("Enter Hotel Name");
		String hotelName = sc.nextLine();
		System.out.println("Enter Hotel Address");
		String address = sc.nextLine();
		System.out.println("Enter description");
		String description = sc.nextLine();
	
		
		System.out.println("Enter phone number");
		String phoneNo1 = sc.next();
		System.out.println("Enter another phone number");
		String phoneNo2 = sc.next();
		System.out.println("Enter rating for hotel");
		String rating = sc.next();
		System.out.println("Enter email Id");
		String email = sc.next();
		System.out.println("Enter fax number");
		String fax = sc.next();

		Hotel hotel = new Hotel(hotelId,city,hotelName,address,description,avgRatePerNight,phoneNo1,phoneNo2,rating,email,fax);
		try {
			Boolean boolean1 = hotelService.addHotelDetails(hotel);
			return boolean1;
		} catch (HBMSException e) {

			e.printStackTrace();
		}
		return null;
	}
	public void deleteHotelDetails(){
		System.out.println("Enter hotelid to delete ");
		int hotelId1 = sc.nextInt();
		try {
			hotelService.deleteHotelDetails(hotelId1);
		} catch (HBMSException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public void displayHotelDetails(){
		List<Hotel> hotelList =new ArrayList<>();
		try {
			hotelList=hotelService.displayHotelDetails();
			showHotelDetails(hotelList);
		} catch (HBMSException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	private static void showHotelDetails(List<Hotel> hotelList) {
		for(Hotel h:hotelList){
			System.out.println(h);
		}

	}
	public Boolean addRoom(){
		System.out.println("Enter Hotel Id");
		Integer hotelId = sc.nextInt();
		//System.out.println("Enter roomId");
		//String roomId = scanner.next();
		System.out.println("Enter room no.");
		String roomNo = sc.next();
		System.out.println("Enter roomtype");
		String roomType = sc.next();
		System.out.println("Enter amount per night");
		Double pernightRate = sc.nextDouble();
		System.out.println("Enter availability");
		String availability = sc.next();
		sc.nextLine();

		Room room=new Room(hotelId,roomNo,roomType,pernightRate,availability);

		try {
			Boolean boolean1 = roomService.addRoomDetails(room);
			return boolean1;
		} catch (HBMSException e) {
			e.printStackTrace();
		}
		return false;
	}
	
	public void deleteRoom(){
		System.out.println("Enter hotelId to delete");
		Integer hotelId1=sc.nextInt();
		System.out.println("Enter roomNo to delete ");
		String roomNo1 = sc.next();

		try {
			roomService.deleteRoomDetails(hotelId1,roomNo1);
		} catch (HBMSException e) {

			e.printStackTrace();
		}
	}
	public void getBookingDetails() {
		System.out.println("Enter hotel id :");
		int hotel_id=sc.nextInt();
		List<BookingDetails> bookingDetails=new ArrayList<>();
		try {
			bookingDetails=bookingService.getBookingDetails(hotel_id);
			for(BookingDetails details:bookingDetails){
				System.out.println(details);
				}
		} catch (HBMSException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}
	public void getBookingDetailsDate() {
		System.out.println("Enter specific date :");
		
		String fromDate=sc.next();
		LocalDate fdate=LocalDate.parse(fromDate);
		List<BookingDetails> bookingDetails=new ArrayList<>();
		try {
			bookingDetails=bookingService.getBookingDetails(fdate);
			for(BookingDetails details:bookingDetails){
			System.out.println(details);
			}
		} catch (HBMSException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}
	public void modifyHotelDetails() {
		System.out.println("1.Modify Hotel Description");
		System.out.println("2.Modify Hotel Price");
		int ch=sc.nextInt();
		switch(ch){
		case 1:
			System.out.println("Enter hotel id:");
			int hotel_id=sc.nextInt();
			System.out.println("Enter Description:");
			String description=sc.next();
			try {
				hotelService.updateDescrption(description, hotel_id);
			} catch (HBMSException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			break;
		case 2:
			System.out.println("Enter hotel id:");
			int hotelid=sc.nextInt();
			System.out.println("Enter Price:");
			Double price=sc.nextDouble();
			try {
				hotelService.updatePrice(price, hotelid);
			} catch (HBMSException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			break;
		}
		
	}
	public void modifyRoomDetails() {
		List<Room> roomList=new ArrayList<>();
		System.out.println("1.Modify Room Price");
		System.out.println("2.Modify Room Type");
		int ch=sc.nextInt();
		switch(ch){
		case 1:
			
			
			try {
				roomList=roomService.displayRoomDetails();
				for(Room h:roomList){
					System.out.println(h);
				}
				System.out.println("Enter Room id:");
				int room_id=sc.nextInt();
				System.out.println("Enter Room price:");
				Double price=sc.nextDouble();
				roomService.updateRoomPrice(room_id,price);
			} catch (HBMSException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			break;
		case 2:
			System.out.println("Enter Room id:");
			int roomid=sc.nextInt();
			System.out.println("Enter Room TYpe:");
			String type=sc.next();
			try {
				roomService.updateType(roomid, type);
			} catch (HBMSException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			break;
		}
		
	}
	

}
