package com.capgemini.hbms.ui;

public class Validator {
	public boolean isValidRole(String role) {

		if(role.equals("User")||role.equals("Employee")||role.equals("Admin"))
			return true;

		else return false;

	}

	public boolean isValidUserName(String user_name) {
		return user_name.matches("[a-zA-Z]{3,}");
	}

	public  boolean isValidMobileNo(String mobile_no) {

		return mobile_no.matches("[1-9]{1}[0-9]{9}");
	}

	public  boolean isValidEmail(String email) {

		return email.matches("[a-z]+@[a-z]+.com");
	}

	public  boolean isValidPhoneNo(String phone) {
		return phone.matches("[1-9]{1}[0-9]{9}");

	}

	public  boolean isValidPassword(String password) {
		return  password.matches("[a-zA-Z]{7}");


	}

	

}
