package com.capgemini.trg.utility;

public class MyMath {
	public static int getMaximumValue(int x,int y,int z){
		if(x>y && x>z)
			return x;
		else if(y>z && y>x)
			return y;
		else
			return z;
	}
	public static long factorial(int n){
		long fact=1;
		for(int i=1;i<=n;i++)
			fact=fact*i;
		return fact;
			
	}
	public static boolean isPrime(int n){
		int i=0;
		if(n>=2){
		for(int j=2;j<n;j++)
		{
			if(n%j==0)
			{
				i=1;
				break;
			}
		}
		if(i==0)
			return true;
		else
			return false;}
		else
			return false;
	}
	public static long sumOfPrimes(int n){
		int i=3;
		long sum=2;
		while(i<=n)
		{
			if(isPrime(i))
				sum=sum+i;
			i++;
		}
		return sum;
		
		
	}
	
}
