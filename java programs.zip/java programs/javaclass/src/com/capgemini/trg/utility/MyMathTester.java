package com.capgemini.trg.utility;

public class MyMathTester {

	public static void main(String[] args) {
		System.out.println("factorial :"+MyMath.factorial(5));
		System.out.println("maxvalue: "+MyMath.getMaximumValue(2,2,22));
		System.out.println("prime: "+MyMath.isPrime(6));
		System.out.println("sum Prime :"+MyMath.sumOfPrimes(10));

	}

}
