package com.capgemini.trg.ui;

public class StringTester {

	public static void main(String[] args) {
		String s1="Hello";
		String s2="Hello";
		System.out.println(s1==s2);
		System.out.println(s1.equals(s2));
		String s3=new String("Hello");
		String s4=new String("Hello");
		
		System.out.println(s3==s4);
		System.out.println(s3.equals(s4));
		String s5=s4.intern();
		System.out.println(s4==s5);
		System.out.println(s1==s5);
		System.out.println(s2==s5);
		String s6=new String("Hiii");
		String s7=s6.intern();
		System.out.println(s6==s7);
		System.out.println(s1.hashCode()+","+s2.hashCode());
		System.out.println(s3.hashCode()+","+s4.hashCode());
		
	}

}
