package com.capgemini.trg.ui;

import java.util.Scanner;

public class ScannerDemo {
	private static Scanner scanner=new Scanner(System.in);

	public static void main(String[] args) {
		
		
		System.out.println("Enter your name:");
		String name=scanner.nextLine();
		System.out.println("Enter your age: ");
		int age=scanner.nextInt();
		System.out.println("your name: "+name+" and your age is : "+age);

	}

}
