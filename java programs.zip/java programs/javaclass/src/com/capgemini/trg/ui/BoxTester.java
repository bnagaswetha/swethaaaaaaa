package com.capgemini.trg.ui;
import com.capgemini.trh.service.Box;;
public class BoxTester {

	public static void main(String[] args) {
		Box box1=new Box();
		System.out.println(box1.getWidth()+","+box1.getDepth()+","+box1.getHeight());
		box1.setDepth(4);
		box1.setHeight(5.6);
		box1.setWidth(7.8);
		System.out.println(box1.getWidth()+","+box1.getDepth()+","+box1.getHeight());
		
		Box box2=new Box(1.2,2.2,3.2);
		
		System.out.println(box2.getWidth()+","+box2.getDepth()+","+box2.getHeight());
		System.out.println("count: "+Box.getBoxcount());
		System.out.println(box1);
		System.out.println(box2);
		System.out.println("Hash code of box1"+box1.hashCode());
		System.out.println("Hash code of box2"+box2.hashCode());
		String str=new String("Hello");
		System.out.println(str);
		
		
		String s1=new String("Hello");
		String s2=new String("Helo");
		if(s1.equals(s2))
			System.out.println("strings equal");
		else
			
			System.out.println("strings not equal");
		
		Box b1=new Box(2,2,3);
		Box b2=new Box(2,2,3);
		System.out.println("Hash code of b1: "+b1.hashCode());
		System.out.println("Hash code of b2: "+b2.hashCode());
		if(b1.equals(b2))
			System.out.println("box objects are equal");
		else
			
			System.out.println("box objects not equal");
		
	}
	
	

}
