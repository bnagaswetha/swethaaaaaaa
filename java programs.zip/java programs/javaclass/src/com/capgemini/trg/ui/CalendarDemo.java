package com.capgemini.trg.ui;

import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

public class CalendarDemo {

	public static void main(String[] args) {
		Calendar today=new GregorianCalendar();
		System.out.println(today);
		
		System.out.println(today.get(Calendar.DATE)+"/"+
		((today.get(Calendar.MONTH))+1)+"/"+today.get(Calendar.YEAR));
		Calendar hiredate=new GregorianCalendar(2012,8,1,10,30,0);
		System.out.println(hiredate.get(Calendar.YEAR)+"/"+hiredate.get(Calendar.MONTH));
		//converting Date object to GregorianCalendar object
		Date d1=new Date();
		Calendar c1=new GregorianCalendar();
		c1.setTime(d1);
		System.out.println(c1.get(Calendar.YEAR));
		//converting  GregorianCalendar object to Date object 
		Date d2=c1.getTime();
		System.out.println(d2);
	}

}
