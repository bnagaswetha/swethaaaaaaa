package com.capgemini.trg.ui;

public class WrapperClassDemo {

	public static void main(String[] args) {
		int x=100;
		Integer xobj=new Integer(x);
		//From jdk4: Auto-boxing
		Integer intobj=x;
		
		int y=xobj.intValue();
		//Auto-unboxing
		int z=xobj;
		System.out.println(x+"  ,"+z);
		
		String str="123";
		int i=Integer.parseInt(str);
		System.out.println(i);

	}

}
