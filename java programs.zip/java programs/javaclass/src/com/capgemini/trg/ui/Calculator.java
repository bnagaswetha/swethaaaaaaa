package com.capgemini.trg.ui;
/**
 * 
 * @author nbandamr
 * This is a tester class that receives three arguments
 * 1.numeric value
 * 2.numeric value
 * operation(add/sub/div/mul)
 * Display the result
 */

public class Calculator {

	public static void main(String[] args) {
	int x=Integer.parseInt(args[0]);
	int y=Integer.parseInt(args[1]);
	String op=args[2];
	switch(op){
	case "add":System.out.println(x+" + "+y+" ="+(x+y));
				break;
	case "sub":System.out.println(x+" - "+y+" ="+(x-y));
	break;
	case "mul":System.out.println(x+" * "+y+" ="+(x*y));
	break;
	case "div":System.out.println(x+" / "+y+" ="+(x/y));
	break;
	default: System.out.println("enter valid operation");
	}
	

	}

}
