package com.capgemini.trg.ui;

public class CastDemo {

	public static void main(String[] args) {
		
		float f=3.5f;
		System.out.println(f);
		double d=f;//implicit casting
		
		int i=127;
		byte b=(byte)i;//explicit casting
		System.out.println(b);
		//reference type
		//implicit casting :down casting
		//instance of subclass pointed by super class reference is implicit
		Object obj=new String("Hello");
		System.out.println(obj.toString());
		
		//explicit casting :upcasting
		//instace of super class pointed by sub class type is explicit
		String s1=(String) new Object();
		//classcastException is thrown
		System.out.println(s1.toString());

	}

}
