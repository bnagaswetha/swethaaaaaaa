package com.capgemini.trg.ui;

import java.util.Scanner;

public class ScannerDemo1 {

	public static void main(String[] args) {
		Scanner scanner=new Scanner("1,2,3,4,5,6,7,8,9,10").useDelimiter(",");
		while(scanner.hasNextInt()){
			int n =scanner.nextInt();
			if(n%2==0){
				System.out.println(n);
			}
		}

	}

}
