package com.capgemini.trg.ui;

import java.util.Date;

public class SystemDemo {

	public static void main(String[] args) {
		long currentTime=System.currentTimeMillis();
		System.out.println(currentTime);
		
		Date today=new Date(1539085370443L);
		System.out.println(today);
		
		long startTime=System.currentTimeMillis();
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			
			e.printStackTrace();
		}
		long endTime=System.currentTimeMillis();
		System.out.println(endTime-startTime);
	}

}
