package com.capgemini.trg.ui;

import java.time.LocalDate;
import java.time.Month;
import java.time.Period;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.FormatStyle;

public class LocaldateDemo {

	public static void main(String[] args) {
		LocalDate today=LocalDate.now();
		System.out.println(today);
		LocalDate hiredate=LocalDate.of(2012, Month.APRIL,10);
		System.out.println(hiredate);
		System.out.println(hiredate.isLeapYear());
		System.out.println(hiredate.getYear());
		System.out.println(hiredate.getMonth());
		System.out.println(hiredate.getDayOfMonth());
		System.out.println(ZonedDateTime.now());
		ZonedDateTime t=ZonedDateTime.now(ZoneId.of("Europe/Paris"));
		System.out.println(t);
		Period period=hiredate.until(today);
		System.out.println(period.getYears());
		System.out.println(period.getMonths());
		System.out.println(period.getDays());
		
		//converting LocalDate to String
		DateTimeFormatter formatter=DateTimeFormatter.ofLocalizedDate(FormatStyle.LONG);
		String s1=formatter.format(today);
		System.out.println(s1);
		
		//converting  String to LocalDate
		String s2="12/10/1999";
		formatter=DateTimeFormatter.ofPattern("dd/MM/yyyy");
		LocalDate localdate=LocalDate.parse(s2,formatter);
		System.out.println(localdate);
		
	}

}
