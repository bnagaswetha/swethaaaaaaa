package com.capgemini.trg.ui;

import com.capgemini.trh.service.Computer;
import com.capgemini.trh.service.PowerState;

public class ComputerTester {

	public static void main(String[] args) {
		Computer computer=new Computer();
		/*System.out.println(computer.getState());
		computer.setState(Computer.COMPUTER_ON);
		System.out.println(computer.getState());
		
		
		computer.setState(10);
		System.out.println(computer.getState());*/
		System.out.println(computer.getState());
		computer.setState(PowerState.ON);
		
		System.out.println(computer.getState());
		//computer.setState(10);
		checkState(computer.getState());
		for(PowerState p:PowerState.values()){
			System.out.println(p);
		}
		System.out.println("_________________________");
		
		for(PowerState p:PowerState.values()){
			System.out.println(p.ordinal());
		}
System.out.println("_________________________");
		
		for(PowerState p:PowerState.values()){
			System.out.println(p.getPoint());
		}
	}

	private static void checkState(PowerState state) {
		switch(state){
		case OFF:System.out.println("Computer is off");
		break;
		case ON:System.out.println("Computer is on");
		break;
		case SUSPEND:System.out.println("Computer is suspend");
		break;
		default:System.out.println("Invalid State");
		}

	}
	
}
