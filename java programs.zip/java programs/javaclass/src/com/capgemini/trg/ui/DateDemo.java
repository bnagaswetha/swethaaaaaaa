package com.capgemini.trg.ui;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class DateDemo {

	public static void main(String[] args) {
		Date today=new Date();
		System.out.println(today);
		Date somedate=new Date(729037);
		System.out.println(somedate);
		long currentTime=today.getTime();
		System.out.println(currentTime);
		System.out.println(System.currentTimeMillis());
		//converting string object to Date object
		String s1="12/10/1999";
		DateFormat dateformat=new SimpleDateFormat("dd/MM/yyyy");
		try {
			Date d1=dateformat.parse(s1);
			System.out.println(d1);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		//converting Date to String 
		dateformat=new SimpleDateFormat("dd-MMMM-yyyy");
		String s2=dateformat.format(today);
		System.out.println(s2);
		
	}

}
