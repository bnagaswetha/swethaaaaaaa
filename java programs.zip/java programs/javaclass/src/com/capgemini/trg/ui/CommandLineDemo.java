package com.capgemini.trg.ui;

public class CommandLineDemo {

	public static void main(String[] args) {
		/*for(int i=0;i<args.length;i++){
			System.out.println(args[i]);
		}*/
		/*System.out.println(args[0]+args[1]);*/
		try{
			int x=Integer.parseInt(args[0]);
			int y=Integer.parseInt(args[1]);
			System.out.println(x+y);
		}catch(NumberFormatException e){
			System.out.println("Invalid data");
		}

	}


}
