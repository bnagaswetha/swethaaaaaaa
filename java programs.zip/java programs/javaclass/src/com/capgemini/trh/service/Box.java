package com.capgemini.trh.service;

public class Box {

	private double width;
	private double height;
	private double depth;
	private static int boxcount;
	//default constructor
	public Box() {
		boxcount++;
	}
	
	

	public Box(double width, double height) {
		super();
		this.width = width;
		this.height = height;
	}



	public Box(double depth) {
		super();
		this.depth = depth;
	}



	//all-arg constructors
	public Box(double width, double height, double depth) {
		super();
		boxcount++;
		this.width = width;
		this.height = height;
		this.depth = depth;
	}
	
	public double getWidth() {
		return width;
	}
	public void setWidth(double width) {
		this.width = width;
	}
	public double getHeight() {
		return height;
	}
	public void setHeight(double height) {
		this.height = height;
	}
	public double getDepth() {
		return depth;
	}
	public void setDepth(double depth) {
		this.depth = depth;
	}
	public static int getBoxcount() {
		return boxcount;
	}



	@Override
	public String toString() {
		return "Box [width=" + width + ", height=" + height + ", depth="
				+ depth + "]";
	}



	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		long temp;
		temp = Double.doubleToLongBits(depth);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		temp = Double.doubleToLongBits(height);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		temp = Double.doubleToLongBits(width);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		return result;
	}



	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Box other = (Box) obj;
		if (Double.doubleToLongBits(depth) != Double
				.doubleToLongBits(other.depth))
			return false;
		if (Double.doubleToLongBits(height) != Double
				.doubleToLongBits(other.height))
			return false;
		if (Double.doubleToLongBits(width) != Double
				.doubleToLongBits(other.width))
			return false;
		return true;
	}
	
	
	
	

}
