package com.capgemini.trh.service;

public class Computer {
	/*public static final int COMPUTER_OFF=0;
	public static final int COMPUTER_ON=1;
	public static final int COMPUTER_SUSPEND=2;
	private int state;
	public Computer() {
		super();
		this.state = COMPUTER_OFF;
	}
	public int getState() {
		return state;
	}
	public void setState(int state) {
		this.state = state;
	}
	*/
	private PowerState state;
	public Computer(){
		this.state=PowerState.OFF;
	}
	public PowerState getState() {
		return state;
	}
	public void setState(PowerState state) {
		this.state = state;
	}
		
}
