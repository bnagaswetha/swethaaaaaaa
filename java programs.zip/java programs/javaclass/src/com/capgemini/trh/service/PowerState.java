package com.capgemini.trh.service;

public enum PowerState {
	OFF(10),ON(20),SUSPEND(30);
	public int getPoint(){
		return point;
	}
	int point;
	
	
	//enum constructors cannot be public, only private or default
	//cannot create enum object through constructor
	//
	PowerState(int point){
		this.point=point;
	}
}
