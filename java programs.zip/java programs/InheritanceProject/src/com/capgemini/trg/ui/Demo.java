package com.capgemini.trg.ui;

import com.capgemini.trg.service.B;

public class Demo {

	public static void main(String[] args) {
		B bobj=new B(2,3);
		System.out.println(bobj.getX()+","+bobj.getY());
	}
	

}
