package com.capgemini.trg.service;

public class B extends A{
	private int y;

	public B() {
		
	}

	public B(int x,int y) {
		super(x);
		this.y = y;
	}
	public int getY(){
		return y;
	}
	

}
