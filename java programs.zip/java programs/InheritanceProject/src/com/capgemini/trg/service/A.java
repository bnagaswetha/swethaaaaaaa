package com.capgemini.trg.service;

public class A {
	private int x;

	public A() {
		
	}

	public A(int x) {
		this.x = x;
	}

	public int getX() {
		return x;
	}
	

}
