package com.capgemini.trg.ui;

import com.capgemini.trg.service.Account;
import com.capgemini.trg.service.CurrentAccount;
import com.capgemini.trg.service.SavingsAccount;

public class InstanceOfDemo {

	public static void main(String[] args) {
		// Instanceof operator
		showInstanceOf(new Account());
		showInstanceOf(new SavingsAccount());
		showInstanceOf(new CurrentAccount());

	}

	private static void showInstanceOf(Account account) {
		if(account instanceof SavingsAccount){
			System.out.println("Received instance of class, SavingsAccount");
		}
		else if(account instanceof CurrentAccount){
			System.out.println("Received instance of class, CurrentAccount");
		}
		else{
			System.out.println("Received instance of class, Account");
		}
		
	}

}
