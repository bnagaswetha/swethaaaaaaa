package com.capgemini.trg.ui;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class TryWithResourceDemo {

	public static void main(String[] args) {
		String studentNames[]=new String[4];
		getStudentNames(studentNames);
		showStudentNames(studentNames);

	}

	private static void showStudentNames(String[] studentNames) {
		for(String s:studentNames){
			System.out.println(s);
		}
	}

	private static void getStudentNames(String[] studentNames) {
		try(
				BufferedReader br=new BufferedReader(new InputStreamReader (System.in));
				){
			for(int i=0;i<studentNames.length;i++){
				System.out.println("Enter student name");
				studentNames[i]=br.readLine();

			}
		}catch(IOException e){
			e.printStackTrace();
		}catch(Exception e){

			e.printStackTrace();
		}
	}

}
