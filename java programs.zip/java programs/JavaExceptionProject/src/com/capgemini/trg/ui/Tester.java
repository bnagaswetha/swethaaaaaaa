package com.capgemini.trg.ui;
//Handling Unchecked Exceptions
public class Tester {

	public static void main(String[] args) {
		try{
		Integer n1=Integer.parseInt(args[0]);
		Integer n2=Integer.parseInt(args[1]);
		double n3=n1/n2;
		System.out.println(n3);
		}/*catch(ArrayIndexOutOfBoundsException e){
			System.out.println("Array index out of bounds exception");
					e.printStackTrace();
		}
		catch(NumberFormatException e){
			System.out.println("Enter valid data");
					e.printStackTrace();
		}
		catch(ArithmeticException e){
			System.out.println("cannot divide by zero");
					e.printStackTrace();
		}
		catch(Exception e){
			
					e.printStackTrace();
		}*/
		catch(NumberFormatException|ArrayIndexOutOfBoundsException|ArithmeticException e){
			e.printStackTrace();
		}
		System.out.println("helo");


	}

}
