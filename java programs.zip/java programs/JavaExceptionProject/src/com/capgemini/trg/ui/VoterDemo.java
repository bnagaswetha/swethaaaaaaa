package com.capgemini.trg.ui;

import com.capgemini.trg.service.AgeVerificationException;
import com.capgemini.trg.service.Voter;

public class VoterDemo {

	public static void main(String[] args) {
		Voter voter=new Voter();
		try {
			voter.getVoterDetails();
		} catch (AgeVerificationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
