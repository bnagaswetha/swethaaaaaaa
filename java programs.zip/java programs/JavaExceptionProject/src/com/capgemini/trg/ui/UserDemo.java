package com.capgemini.trg.ui;

import com.capgemini.trg.service.CredentialException;
import com.capgemini.trg.service.User;

public class UserDemo {

	public static void main(String[] args) {
		User user=new User();
		try {
			user.getUserDetails();
		} catch (CredentialException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println("you must give username and password different");
		}

	}

}
