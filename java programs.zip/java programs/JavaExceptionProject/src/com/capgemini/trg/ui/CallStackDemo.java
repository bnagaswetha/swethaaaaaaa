package com.capgemini.trg.ui;

public class CallStackDemo {

	public static void main(String[] args) {
		try{
			System.out.println(divideArray(args));
		}catch(Exception e){
			e.printStackTrace();
		}
		
	}

	private static int divideArray(String[] args) {
		String s1=args[0];
		String s2=args[1];
		return divideStrings(s1,s2);
	}

	private static int divideStrings(String s1, String s2) {
		int n1=Integer.parseInt( s1);
		int n2=Integer.parseInt( s2);
		return divideInt(n1,n2);
	}

	private static int divideInt(int n1, int n2) {
		try{
			return n1/n2;
		}catch(ArithmeticException e){
			System.out.println("Exception trapped in divideINt()");
			throw e;
		}
		
	}

}
