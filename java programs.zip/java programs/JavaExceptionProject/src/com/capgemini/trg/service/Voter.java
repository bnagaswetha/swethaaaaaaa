package com.capgemini.trg.service;

import java.util.Scanner;

public class Voter {
	private String name;
	private int age;
	public void getVoterDetails() throws AgeVerificationException{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Voter name");
		this.name=sc.nextLine();
		sc.next();
		System.out.println("Enter Voter age");
		int temp=sc.nextInt();
		if(temp<18){
			throw new AgeVerificationException(temp);
		}
		this.age=temp;
		
	}

}
