package com.capgemini.trg.service;

import java.util.Scanner;

public class User {
	private String name;
	private String password;
	
	public void getUserDetails() throws CredentialException{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter user name");
		 String tname=sc.nextLine();
		
		System.out.println("Enter user password");
		String tpassword=sc.next();
		if(tname.equals(tpassword)){
			throw new CredentialException(name,password);
		}
		this.name=tname;
		this.password=tpassword;
		System.out.println("Valid username and password");
	}
}
