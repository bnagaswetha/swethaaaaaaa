package com.capgemini.trg.service;

public class CredentialException extends Exception{
	private String uname;
	private String password;
	public CredentialException(String uname, String password) {
		super();
		this.uname = uname;
		this.password = password;
	}
	public String getUname() {
		return uname;
	}
	public String getPassword() {
		return password;
	}
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return super.toString()+"username and password are equal";
	}
	

}
