package com.capgemini.trg.service;

public class AgeVerificationException extends Exception {
	private int age;

	public AgeVerificationException(int age) {
		super();
		this.age = age;
	}

	public int getAge() {
		return age;
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return super.toString();
	}

	
}
