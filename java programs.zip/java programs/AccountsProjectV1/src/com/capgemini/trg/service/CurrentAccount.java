package com.capgemini.trg.service;

import java.time.LocalDate;

public class CurrentAccount extends Account {
	private static final Double  RATE_OF_INTEREST=2.4;
	private String officeAddress;
	public CurrentAccount(Long accountNumber, String accountHolder,
			LocalDate accountOpeningDate, Double balance, String officeAddress) {
		super(accountNumber, accountHolder, accountOpeningDate, balance);
		this.officeAddress = officeAddress;
	}
	
	public CurrentAccount() {
		super();
	}

	public String getOfficeAddress() {
		return officeAddress;
	}

	public void setOfficeAddress(String officeAddress) {
		this.officeAddress = officeAddress;
	}
	

	@Override
	public String toString() {
		
		return "CurrentAccount Details..\n"+
		super.toString()+"\n"+
		"[officeAddress=" + officeAddress;
	}

	@Override
	public Double withdraw(Double amount) {
		if(this.getBalance()<0.0){
			System.out.println("No balance amount in your Current account");
			return -1.0;
		}
		else if(this.getBalance()<amount){
			System.out.println("Insufficient funds in your current account");
			
			return 0.0;
		}
		else if((this.getBalance()-amount)<10000){
			System.out.println("Minimum balance  10000 should be maintained in your current account");
			this.setBalance(this.getBalance()-amount);
			return amount;
			
		}
		
		else{
			this.setBalance(this.getBalance()-amount);
			return amount;
		}
	}
	

}
