package com.capgemini.trg.service;

import java.time.LocalDate;

public abstract class Account {
	private Long accountNumber;
	private String accountHolder;
	private LocalDate accountOpeningDate;
	private Double balance;
	private static String bankName;
	static{
		bankName="AXIS Bank";
	}
	public Account() {
		super();
	}
	public Account(Long accountNumber, String accountHolder,
			LocalDate accountOpeningDate, Double balance) {
		super();
		this.accountNumber = accountNumber;
		this.accountHolder = accountHolder;
		this.accountOpeningDate = accountOpeningDate;
		this.balance = balance;
	}
	public Long getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(Long accountNumber) {
		this.accountNumber = accountNumber;
	}
	public String getAccountHolder() {
		return accountHolder;
	}
	public void setAccountHolder(String accountHolder) {
		this.accountHolder = accountHolder;
	}
	public LocalDate getAccountOpeningDate() {
		return accountOpeningDate;
	}
	public void setAccountOpeningDate(LocalDate accountOpeningDate) {
		this.accountOpeningDate = accountOpeningDate;
	}
	public Double getBalance() {
		return balance;
	}
	public void setBalance(Double balance) {
		this.balance = balance;
	}
	public void deposit(Double amount){
		this.balance=this.balance+amount;
	}
	public abstract Double withdraw(Double amount);
		
	@Override
	public String toString() {
		return "Account [accountNumber=" + accountNumber + ", accountHolder="
				+ accountHolder + ", accountOpeningDate=" + accountOpeningDate
				+ ", balance=" + balance + "]";
	}
	

}
