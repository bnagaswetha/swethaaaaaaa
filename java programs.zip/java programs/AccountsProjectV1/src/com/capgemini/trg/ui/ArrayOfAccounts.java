package com.capgemini.trg.ui;

import java.time.LocalDate;

import com.capgemini.trg.service.Account;
import com.capgemini.trg.service.CurrentAccount;
import com.capgemini.trg.service.SavingsAccount;

public class ArrayOfAccounts {

	public static void main(String[] args) {
		//Array of references of type Account
		Account accounts[]=new Account[4];
		populateAccounts(accounts);
		showAccountDetails(accounts);
		double totalAmount=getTotalAmountInBank(accounts);
		System.out.println("Total hard cash in the bank is: "+totalAmount);
		transaction(accounts);
	}

	private static void transaction(Account[] accounts) {
		for(Account a:accounts){
			a.withdraw(2000000.00);
		}
		
	}

	private static void populateAccounts(Account[] accounts) {
		accounts[0]=new SavingsAccount(1001L,"Smith",LocalDate.of(2017,3,12),5000.00,"Hyderabad");
		accounts[1]=new CurrentAccount(2001L,"Jones",LocalDate.of(2017,3,12),50000.00,"Chennai");
		accounts[2]=new CurrentAccount(2002L,"Clarke",LocalDate.of(2016,3,12),6000.00,"Bangalore");
		accounts[3]=new SavingsAccount(2003L,"Jake",LocalDate.of(2016,3,12),70000.00,"Pune");
	}

	private static double getTotalAmountInBank(Account[] accounts) {
		double total=0.0;
		for(Account a:accounts){
			total+=a.getBalance();
		}
		return total;
	}

	private static void showAccountDetails(Account[] accounts) {
		for(Account a:accounts){
			System.out.println(a);
		}
		
	}

}
