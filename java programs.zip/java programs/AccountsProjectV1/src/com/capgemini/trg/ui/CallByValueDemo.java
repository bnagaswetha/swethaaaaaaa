package com.capgemini.trg.ui;

import java.time.LocalDate;

import com.capgemini.trg.service.Account;
import com.capgemini.trg.service.SavingsAccount;

public class CallByValueDemo {

	public static void main(String[] args) {
		Account account=new SavingsAccount(1001L,"Smith",LocalDate.of(2017,3,12),5000.00,"Hyderabad");
		System.out.println(account.getBalance());
		/*updateBalance(account);
		*/
		account=updateBalance(account);
		System.out.println(account.getBalance());
	}

	private static Account updateBalance(Account account) {
		Account newaccount=new SavingsAccount(2001L,"Jones",LocalDate.of(2017,3,12),50000.00,"Chennai");
		return account;
	}

	/*private static void updateBalance(Account account) {
		//Account anotherAccount=account;
		//anotherAccount.deposit(1000.00);
		Account newaccount=new SavingsAccount(2001L,"Jones",LocalDate.of(2017,3,12),50000.00,"Chennai");
		newaccount.deposit(1000.00);
		account=newaccount;
		
	}
*/
}
