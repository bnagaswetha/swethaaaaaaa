package com.capgemini.trg.ui;

import java.time.LocalDate;

import com.capgemini.trg.service.Account;
import com.capgemini.trg.service.SavingsAccount;

public class AccountTester {

	public static void main(String[] args) {
		Account account=new SavingsAccount(1001L,"Smith",LocalDate.of(2017,3,12),5000.00,"Hyderabad");
		System.out.println(account);
		double amount=account.withdraw(3000.00);
		System.out.println("Withdrawl amount =Rs."+amount);
		System.out.println("Balance after Withdrawl amount =Rs."+account.getBalance());
		account.deposit(1450.00);
		System.out.println("Balance after Deposit amount =Rs."+account.getBalance());
	}

}
