package com.capgemini.trg.service;

import java.time.LocalDate;

public class Customer implements Comparable<Customer> {
	private Integer customerid;
	private String customerName;
	private LocalDate birthdate;
	private String address;
	private Long mobile;
	private String email;
	private String password;
	public Customer() {
		super();
	}
	public Customer(Integer customerid, String customerName,
			LocalDate birthdate, String address, Long mobile, String email,
			String password) {
		super();
		this.customerid = customerid;
		this.customerName = customerName;
		this.birthdate = birthdate;
		this.address = address;
		this.mobile = mobile;
		this.email = email;
		this.password = password;
	}
	public Integer getCustomerid() {
		return customerid;
	}
	public void setCustomerid(Integer customerid) {
		this.customerid = customerid;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public LocalDate getBirthdate() {
		return birthdate;
	}
	public void setBirthdate(LocalDate birthdate) {
		this.birthdate = birthdate;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public Long getMobile() {
		return mobile;
	}
	public void setMobile(Long mobile) {
		this.mobile = mobile;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	@Override
	public String toString() {
		return "Customer [customerid=" + customerid + ", customerName="
				+ customerName + ", birthdate=" + birthdate + ", address="
				+ address + ", mobile=" + mobile + ", email=" + email
				+ ", password=" + password + "]";
	}
	/*@Override
	public int compareTo(Object arg0) {
		Customer c=(Customer)arg0;
		if(this.customerid<c.customerid){
			return -1;
		}
		else if(this.customerid>c.customerid){
			return 1;
			
		}
		return 0;
	}*/
	@Override
	public int compareTo(Customer o) {
		
		return this.getCustomerid().compareTo(o.customerid);
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((address == null) ? 0 : address.hashCode());
		result = prime * result
				+ ((birthdate == null) ? 0 : birthdate.hashCode());
		result = prime * result
				+ ((customerName == null) ? 0 : customerName.hashCode());
		result = prime * result
				+ ((customerid == null) ? 0 : customerid.hashCode());
		result = prime * result + ((email == null) ? 0 : email.hashCode());
		result = prime * result + ((mobile == null) ? 0 : mobile.hashCode());
		result = prime * result
				+ ((password == null) ? 0 : password.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Customer other = (Customer) obj;
		if (address == null) {
			if (other.address != null)
				return false;
		} else if (!address.equals(other.address))
			return false;
		if (birthdate == null) {
			if (other.birthdate != null)
				return false;
		} else if (!birthdate.equals(other.birthdate))
			return false;
		if (customerName == null) {
			if (other.customerName != null)
				return false;
		} else if (!customerName.equals(other.customerName))
			return false;
		if (customerid == null) {
			if (other.customerid != null)
				return false;
		} else if (!customerid.equals(other.customerid))
			return false;
		if (email == null) {
			if (other.email != null)
				return false;
		} else if (!email.equals(other.email))
			return false;
		if (mobile == null) {
			if (other.mobile != null)
				return false;
		} else if (!mobile.equals(other.mobile))
			return false;
		if (password == null) {
			if (other.password != null)
				return false;
		} else if (!password.equals(other.password))
			return false;
		return true;
	}
	
	
	
}
