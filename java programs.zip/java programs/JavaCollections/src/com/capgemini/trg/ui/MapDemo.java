package com.capgemini.trg.ui;

import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public class MapDemo {

	public static void main(String[] args) {
		Map<String,String> countryMap=new HashMap<>();
		countryMap.put("India","New delhi");
		countryMap.put("USA","Washington");
		countryMap.put("Germany","Berlin");
		countryMap.put("India","Delhi");
		countryMap.put(null,null);
		countryMap.put(null,"hello");
		countryMap.put(null,null);
		System.out.println(countryMap.size());
		for(Map.Entry<String, String> e:countryMap.entrySet()){
			System.out.println(e.getKey()+":"+e.getValue());
		}
		//only keys are stored in HashSet, countryNames
		System.out.println("-------------");
		Set<String> countryNames=countryMap.keySet();
		Iterator<String> iterator=countryNames.iterator();
		while(iterator.hasNext()){
			String key=iterator.next();
			System.out.println(key+":"+countryMap.get(key));
		}
		System.out.println("-------------");
		Collection<String> cityList=countryMap.values();
		Iterator<String> iterator1=cityList.iterator();
		while(iterator1.hasNext()){
			
			System.out.println(iterator1.next());
		}
		/*
		 * keySet(): returns only keys
		 * entrySet(): returns both key:value pairs
		 * values(): returns only values
		 */
	} 

}
