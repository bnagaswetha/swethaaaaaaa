package com.capgemini.trg.ui;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

public class StringListDemo {
		private static Scanner scanner=new Scanner(System.in);
		public static void main(String[] args) {
		List<String> namesList=new ArrayList<>();
		getNames(namesList);
		showNames(namesList);
		

	}
		private static void getNames(List<String> namesList) {
			while(true){
				System.out.println("Enter student name:");
				namesList.add(scanner.nextLine());
				System.out.println("To continue, type yes");
				String choice=scanner.nextLine();
				if(!choice.equalsIgnoreCase("yes")){
					break;
				}
			
			}
			
		}
		private static void showNames(List<String> namesList) {
			System.out.println("Iterating through for loop..");
			for(int i=0;i<namesList.size();i++){
				System.out.println(namesList.get(i));
			}
			System.out.println("Using Iterator..");
			Iterator<String> iterator=namesList.iterator();
			while(iterator.hasNext()){
				System.out.println(iterator.next());
			}
			
		}

}
