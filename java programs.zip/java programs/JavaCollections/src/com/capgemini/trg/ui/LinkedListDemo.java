package com.capgemini.trg.ui;

import java.util.Iterator;
import java.util.LinkedList;

import com.capgemini.trg.service.Customer;

public class LinkedListDemo {

	public static void main(String[] args) {
		LinkedList<String> myList=new LinkedList<>();
		myList.add("Java EE");
		myList.add("JPA");
		myList.addFirst("Java SE");
		System.out.println(myList.size());
		myList.removeFirst();
		System.out.println(myList.size());
		myList.addLast("Spring");
		myList.removeLast();
		Iterator<String> iterator=myList.iterator();
		while(iterator.hasNext()){
			System.out.println(iterator.next());
		}

	}

}
