package com.capgemini.trg.ui;

import java.time.LocalDate;
import java.util.LinkedHashMap;
import java.util.Map;

import com.capgemini.trg.service.Customer;

public class CustomerMapDemo {

	public static void main(String[] args) {
		Map<Integer,Customer> customerMap=new LinkedHashMap<>();
		populateCustomers(customerMap);
		showCustomers(customerMap);

	}

	private static void showCustomers(Map<Integer, Customer> customerMap) {
		for(Map.Entry<Integer,Customer>c:customerMap.entrySet()){
			System.out.println("Customer Id: "+c.getKey());
			System.out.println("Customer Details: "+c.getValue());
		}
		
	}

	private static void populateCustomers(Map<Integer, Customer> customerMap) {
		Customer c1=new Customer(1002,"Smith",LocalDate.of(1998,12,7),"Hyderabad",
				573453845L,"smith@gmail.com","smith98");
		Customer c2=new Customer(1001,"Jake",LocalDate.of(1997,2,17),"Chennai",
				5734535L,"jake@gmail.com","jake98");
		Customer c3=new Customer(1004,"Mohan",LocalDate.of(1988,6,9),"Pune",
				57333845L,"Mohan@gmail.com","mohan8");
		Customer c4=new Customer(1003,"Pk",LocalDate.of(1996,7,22),"Delhi",
				873453845L,"pk@gmail.com","pk6");
		Customer c5=new Customer(1002,"Smith",LocalDate.of(1998,12,7),"Hyderabad",
				573453845L,"smith@gmail.com","smith98");
		customerMap.put(c1.getCustomerid(),c1);
		customerMap.put(c2.getCustomerid(),c2);
		customerMap.put(c3.getCustomerid(),c3);
		customerMap.put(c4.getCustomerid(),c4);
		customerMap.put(c5.getCustomerid(),c5);
	}

}
