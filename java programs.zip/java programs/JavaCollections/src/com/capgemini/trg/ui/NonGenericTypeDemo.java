package com.capgemini.trg.ui;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class NonGenericTypeDemo {

	public static void main(String[] args) {
		//List is NonGeneric type
		List myList=new ArrayList();
		myList.add(new Integer(100));
		myList.add(new String("Hello"));
		myList.add(new Date());
		int x=(int)myList.get(0);
		String message=(String)myList.get(1);
		int sum=0;
		for(int i=0;i<myList.size();i++){
			sum=sum+(Integer)myList.get(i);
		}
		System.out.println(sum);

	}

}
