package com.capgemini.trg.ui;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

public class GenericTypeDemo {

	public static void main(String[] args) {
		//Generic type
		List<Integer> myList=new ArrayList<>();
		myList.add(new Integer(120));
		myList.add(78);//auto boxing takes place(converion from primitive type to object type)
		//placing objects of another type leads to compilation error
		//myList.add(new String("hello"));
		System.out.println(myList.get(0)+",\t"+myList.get(1));
		int sum=0;
		for(int i=0;i<myList.size();i++){
			sum+=myList.get(i);
		}
		System.out.println(sum);
		myList.add(0, 90);
		System.out.println(myList.size());
		System.out.println(myList.get(0));
		
		Object[] myIntArray=myList.toArray();
		for(Object o:myIntArray){
			System.out.println((int)o);
		}
		Integer marks[]={65,78,44,36};
		List<Integer> marksList=Arrays.asList(marks);
		Iterator<Integer> iterator=marksList.iterator();
		while(iterator.hasNext()){
			System.out.println(iterator.next());
		}
	}

}
