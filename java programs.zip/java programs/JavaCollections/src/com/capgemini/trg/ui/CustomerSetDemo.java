package com.capgemini.trg.ui;

import java.time.LocalDate;
import java.util.Iterator;
import java.util.Set;
import java.util.TreeSet;

import com.capgemini.trg.service.Customer;
import com.capgemini.trg.service.CustomerNameComparator;

public class CustomerSetDemo {

	public static void main(String[] args) {
		/*Customer objects are arranged in the treeSet based on their customerIds i.e,key attribute
		 * Set<Customer> customerSet=new TreeSet<>();
		 */
		//Customer objects are arranged in the treeSet based on their customernames i.e,non key attribute
		Set<Customer> customerSet=new TreeSet<>(new CustomerNameComparator());
		populateCustomerSet(customerSet);
		System.out.println(customerSet.size());
		showCustomerSet(customerSet);

	}

	private static void showCustomerSet(Set<Customer> customerSet) {
		Iterator<Customer> iterator=customerSet.iterator();
		while(iterator.hasNext()){
			System.out.println(iterator.next());
		}

	}

	private static void populateCustomerSet(Set<Customer> customerSet) {

		Customer c1=new Customer(1002,"Smith",LocalDate.of(1998,12,7),"Hyderabad",
				573453845L,"smith@gmail.com","smith98");
		Customer c2=new Customer(1001,"Jake",LocalDate.of(1997,2,17),"Chennai",
				5734535L,"jake@gmail.com","jake98");
		Customer c3=new Customer(1004,"Mohan",LocalDate.of(1988,6,9),"Pune",
				57333845L,"Mohan@gmail.com","mohan8");
		Customer c4=new Customer(1003,"Pk",LocalDate.of(1996,7,22),"Delhi",
				873453845L,"pk@gmail.com","pk6");
		Customer c5=new Customer(1002,"Smith",LocalDate.of(1998,12,7),"Hyderabad",
				573453845L,"smith@gmail.com","smith98");
		customerSet.add(c1);
		customerSet.add(c2);
		customerSet.add(c3);
		customerSet.add(c4);
		customerSet.add(c5);

	}

}
