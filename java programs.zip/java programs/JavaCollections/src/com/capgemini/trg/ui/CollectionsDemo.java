package com.capgemini.trg.ui;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;

public class CollectionsDemo {

	public static void main(String[] args) {
		List<String> namesList=new ArrayList<>();
		namesList.add("Java SE");
		namesList.add("Java EE");
		namesList.add("Spring");
		namesList.add("JPA");
		
		Collections.sort(namesList);
		Iterator<String> iterator=namesList.iterator();
		while(iterator.hasNext()){
			System.out.println(iterator.next());
		}
		int p1=Collections.binarySearch(namesList,"JPA");
		System.out.println(p1);
		
		List<String> namesNewList=Collections.synchronizedList(namesList);
		System.out.println(namesNewList.size());
		Iterator<String> iterator1=namesNewList.iterator();
		while(iterator1.hasNext()){
			System.out.println(iterator1.next());
		}
		
		Hashtable<Integer,String> myTable=new Hashtable<>();
		myTable.put(1,"Sri");
		myTable.put(2,"Sai");
		//myTable.put(null,"Krishna");
		Enumeration<Integer> e=myTable.keys();
		while(e.hasMoreElements()){
			Integer k=e.nextElement();
			System.out.println(k+":"+myTable.get(k));
		}
		
	}

}
