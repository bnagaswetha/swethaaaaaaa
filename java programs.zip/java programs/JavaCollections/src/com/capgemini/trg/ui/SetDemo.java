package com.capgemini.trg.ui;

import java.util.Iterator;
import java.util.Set;
import java.util.TreeSet;

public class SetDemo {

	public static void main(String[] args) {
		Set<String> nameSet=new TreeSet<>();
		nameSet.add(new String("Hello"));
		nameSet.add(new String("Welcome"));
		nameSet.add(new String("Hi"));
		nameSet.add(new String("Java"));
		nameSet.add(new String("Hello"));
		Iterator<String> iterator=nameSet.iterator();
		while(iterator.hasNext()){
			System.out.println(iterator.next());
		}

	}

}
