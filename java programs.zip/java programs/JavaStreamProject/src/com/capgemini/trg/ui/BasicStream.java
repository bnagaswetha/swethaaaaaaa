package com.capgemini.trg.ui;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;

import com.capgemini.trg.service.Customer;

public class BasicStream {

	public static void main(String[] args) {
		Stream<String> stream=Stream.of("C","a","p","g","e","m","i","n","i");
		stream.forEach((s)->System.out.println(s));
		stream.close();
		System.out.println("------------------");
		stream=Stream.of("C","a","p","g","e","m","i","n","i");
		stream.forEach(System.out::println);
		List<String> cityList=Arrays.asList(new String[]{ "Hyderabad","Mumbai","Pune","Chennai"});
		Stream<String> stream1=cityList.stream();
		stream1.map((str)->str.length()).forEach(System.out::println);;
		System.out.println("------------------");
		List<Customer> customerList=new ArrayList<>();
		populateCustomerList(customerList);
		Stream<Customer> customerStream=customerList.stream();
		customerStream.forEach(System.out::println);

	}

	private static void populateCustomerList(List<Customer> customerList) {
		customerList.add(new Customer(1002,"Smith",LocalDate.of(1998,12,7),"Hyderabad",
				573453845L,"smith@gmail.com","smith98"));
		customerList.add(new Customer(1001,"Jake",LocalDate.of(1997,2,17),"Chennai",
				5734535L,"jake@gmail.com","jake98"));
		customerList.add(new Customer(1004,"Mohan",LocalDate.of(1988,6,9),"Pune",
				57333845L,"Mohan@gmail.com","mohan8"));
		customerList.add(new Customer(1003,"Pk",LocalDate.of(1996,7,22),"Delhi",
				873453845L,"pk@gmail.com","pk6"));
		
	}

}
