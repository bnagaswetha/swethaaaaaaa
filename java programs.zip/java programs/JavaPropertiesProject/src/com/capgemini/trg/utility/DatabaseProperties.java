package com.capgemini.trg.utility;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Properties;

public class DatabaseProperties {
	private static Properties properties=new Properties();
	static{
		properties.setProperty("url","jdbc:oracle:thin:@localhost:1521:orcl");
		properties.setProperty("driver","oracle.jdbc.driver.OracleDriver");
		properties.setProperty("username","scott");
		properties.setProperty("password","tiger");
		
	}
	public static void saveProperties(String fileName){
		try(
			FileOutputStream fos=new FileOutputStream(fileName);
			
				
		){
			properties.store(fos, "Oracle Property file");
			System.out.println("Property file created");
			
		}catch(IOException e){
			e.printStackTrace();
			
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	public static Properties loadProperties(String fileName){
		File file=new File(fileName);
		if(file.exists() && file.canRead()){
			try(
					FileInputStream fis=new FileInputStream(file);	
					
			){
				Properties properties=new Properties();
				properties.load(fis);
				return properties;
				
			}catch(IOException e){
				e.printStackTrace();
			}catch(Exception e){
				e.printStackTrace();
			}
			return null;
			
		}else{
			System.out.println("unable to open this file");
			return null;
		}
		
		
	}
}
