package com.capgemini.trg.ui;

import java.util.Properties;

import com.capgemini.trg.utility.DatabaseProperties;

public class PropertiesTester {

	public static void main(String[] args) {
		String fileName="D:\\Data\\oracledb.properties";
		DatabaseProperties.saveProperties(fileName);
		Properties properties=DatabaseProperties.loadProperties(fileName);
		properties.list(System.out);
		System.out.println("____________");
		System.out.println(properties.getProperty("username"));

	}

}
