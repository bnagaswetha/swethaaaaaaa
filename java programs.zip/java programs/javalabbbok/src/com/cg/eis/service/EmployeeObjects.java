package com.cg.eis.service;

import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import com.cg.eis.bean.Employee;
import com.cg.eis.exception.EmployeeException;

public class EmployeeObjects {

	public static void main(String[] args) {
		File file =new File("D:\\data\\employee.ser");
		List<Employee> employees = populateEmployees();
		writeEmployeesToFile(file,employees);
		readEmployeesFromFile(file);


	}

	private static void readEmployeesFromFile(File file) {
		if(file.exists() && file.canRead()){
			try(
					FileInputStream fis = new FileInputStream(file);
					ObjectInputStream ois = new ObjectInputStream(fis);
					){

				while(true){
					Employee employee = (Employee)ois.readObject();
					employee.getDetails(employee);

				}
			}catch(EOFException e){
				System.out.println("End of the file reached");
			}catch(IOException e){
				e.printStackTrace();
			}catch (EmployeeException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}catch(Exception e){
				e.printStackTrace();
			}
		}else{
			System.out.println("Unable to open this file");
		}



	}

	private static void writeEmployeesToFile(File file, List<Employee> employees) {
		
			
			try(
					FileOutputStream fos = new FileOutputStream(file);
					ObjectOutputStream oos = new ObjectOutputStream(fos);
					){
				Iterator<Employee> iterator = employees.iterator();
				while(iterator.hasNext()){
					
					oos.writeObject(iterator.next());
				}oos.flush();
				System.out.println("Employee Serialization Completed");
				
			}catch(IOException e){
				
			}catch(Exception e){
				
			}


	}

	private static List<Employee> populateEmployees() {
		Scanner scanner=new Scanner(System.in);
		System.out.println("Enter employee name");
		String name=scanner.nextLine();
		System.out.println("Enter employee id");
		int id =scanner.nextInt();
		System.out.println("Enter employee salary");
		Double salary=scanner.nextDouble();
		EmployeeService es=new EmployeeService();
		es.scheme(salary);
	
			Employee emp1=new Employee(id,name,salary,es.getDesignation(),es.getInsuranceScheme());
			List employeeList=Arrays.asList(emp1);
			//emp1.getDetails(emp1);
			return employeeList;
		
		

	}

}
