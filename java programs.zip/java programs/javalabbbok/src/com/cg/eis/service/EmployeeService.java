package com.cg.eis.service;

public class EmployeeService implements IEmployeeService{
	private double salary;
	private String designation;
	private String insuranceScheme;

	@Override
	public void scheme(double salary) {
		if(salary>5000 &&salary<20000){
			this.designation="System Associate";
			this.insuranceScheme="Scheme C";
		}
		else if(salary>=20000 &&salary<40000){
			this.designation="Programmer";
			this.insuranceScheme="Scheme B";
		}
		else if(salary>=40000){
			this.designation="Manager";
			this.insuranceScheme="Scheme A";
		}
		else{
			this.designation="Clerk";
			this.insuranceScheme="No Scheme";
		}
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

	public String getDesignation() {
		return designation;
	}

	public void setDesignation(String designation) {
		this.designation = designation;
	}

	public String getInsuranceScheme() {
		return insuranceScheme;
	}

	public void setInsuranceScheme(String insuranceScheme) {
		this.insuranceScheme = insuranceScheme;
	}
	
	
}
