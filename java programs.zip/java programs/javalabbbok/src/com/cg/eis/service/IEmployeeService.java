package com.cg.eis.service;

public interface IEmployeeService {
	void scheme(double salary);

}
