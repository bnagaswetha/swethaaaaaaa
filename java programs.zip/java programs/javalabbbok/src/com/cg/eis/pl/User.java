package com.cg.eis.pl;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

import com.cg.eis.bean.Employee;
import com.cg.eis.exception.EmployeeException;
import com.cg.eis.service.EmployeeService;

public class User {

	public static void main(String[] args) {
		//5.1
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter employee name");
		String name=sc.next();
		System.out.println("Enter employee id");
		int id=sc.nextInt();
		System.out.println("Enter employee salary");
		double salary=sc.nextDouble();
		EmployeeService es=new EmployeeService();
		es.scheme(salary);
		Employee emp=new Employee(id,name,salary,es.getDesignation(),es.getInsuranceScheme());
		System.out.println("Employee Details:");
		try {
			emp.getDetails(emp);
		} catch (EmployeeException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//7.3
		
		/*Map<Integer,Employee> employeeMap=new LinkedHashMap<>();
		populateEmployees(employeeMap);
		showEmployees(employeeMap);
		System.out.println("-------------");
		boolean bool=deleteEmployees(employeeMap);
		System.out.println(bool);
		System.out.println("After Deletion:");
		showEmployees(employeeMap);
		System.out.println("----------");
		System.out.println("After sorting:");
		sortEmployees(employeeMap);
		showEmployees(employeeMap);*/
		
		
	}

	/*private static void sortEmployees(Map<Integer, Employee> employeeMap) {
		List<Map.Entry<Integer,Employee>> list=new ArrayList<>(employeeMap.entrySet());
		Collections.sort(list,new Comparator<Map.Entry<Integer,Employee>>(){
			public int compare(Map.Entry<Integer,Employee> e1,Map.Entry<Integer,Employee> e2){
				return e1.getValue().getSalary().compareTo(e2.getValue().getSalary());
				
			}
			
		});
		System.out.println(list);
		
	}

	private static boolean deleteEmployees(Map<Integer, Employee> employeeMap) {
		System.out.println("Enter employee id which you want to delete:");
		Scanner sc=new Scanner(System.in);
		int id=sc.nextInt();
		if(employeeMap.containsKey(id)){
		employeeMap.remove(id);
		return true;
		}else{
			return false;
		}
		
		
	}

	private static void showEmployees(Map<Integer, Employee> employeeMap) {
		for(Map.Entry<Integer,Employee>e:employeeMap.entrySet()){
			System.out.println("Employee Id: "+e.getKey());
			System.out.println("Employee Details: "+e.getValue());
		}
		
	}

	private static void populateEmployees(Map<Integer, Employee> employeeMap) {
		System.out.println("Enter number of employees:");
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		for(int i=1;i<=n;i++){
			System.out.println("Enter employee name");
			String name=sc.next();
			System.out.println("Enter employee id");
			int id=sc.nextInt();
			System.out.println("Enter employee salary");
			double salary=sc.nextDouble();
			sc.nextLine();
			System.out.println("Enter employee scheme");
			String scheme=sc.nextLine();
			EmployeeService es=new EmployeeService();
			es.scheme(salary);
			//System.out.println(es.getInsuranceScheme().getClass());
			//System.out.println((es.getInsuranceScheme()).equals(scheme));
			
			if((es.getInsuranceScheme()).equalsIgnoreCase(scheme)){
				Employee emp=new Employee(id,name,salary,es.getDesignation(),es.getInsuranceScheme());
				employeeMap.put(emp.getId(),emp);
			}
			else{
				System.out.println("Scheme was incorrect with respect to salary");
				System.out.println("Correct scheme is:");
				System.out.println("if salary>5000 &&salary<20000 then "
						+ "designation=System Associate and	this.insuranceScheme=Scheme C");
				System.out.println("if salary>=20000 &&salary<40000 then"
						+ "	designation=Programmer and insuranceScheme=Scheme B");
				System.out.println("if salary>=40000 then designation=Manager"
						+ " and insuranceScheme=Scheme A");
				System.out.println("if salary<5000 then designation=Clerk and "
						+ "insuranceScheme=No Scheme");
			
			}
			
		}
		
	}
*/
}
