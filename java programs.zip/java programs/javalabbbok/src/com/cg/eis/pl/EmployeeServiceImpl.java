package com.cg.eis.pl;

import java.util.HashMap;
import java.util.Scanner;

import com.cg.eis.bean.Employee;
import com.cg.eis.service.EmployeeService;

public class EmployeeServiceImpl {


	HashMap<String,Employee> list=new HashMap<String,Employee>();



	public boolean deleteEmployee(int id) {
		list.remove(id);
		return true;
	}

	public void addEmployee(Employee emp) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter employee name");
		String name=sc.next();
		System.out.println("Enter employee id");
		int id=sc.nextInt();
		System.out.println("Enter employee salary");
		double salary=sc.nextDouble();
		sc.nextLine();
		System.out.println("Enter employee scheme");
		String scheme=sc.nextLine();
		EmployeeService es=new EmployeeService();
		es.scheme(salary);

		emp=new Employee(id,name,salary,es.getDesignation(),es.getInsuranceScheme());

		list.put(name,emp);
	}

	
	public static void main(String args[]){
		
	}





}
