package com.capgemini.trg.lab5;

public abstract class Account {
	private long accNum;
	private double balance;
	private Person accHolder;
	static int acc=1000;
	public Account() {
		super();
	}
	public Account(double balance, Person accHolder) {
		super();
		acc+=1;
		this.accNum = acc;
		this.balance = balance;
		this.accHolder = accHolder;
	}
	public long getAccNum() {
		return accNum;
	}
	public void setAccNum(long accNum) {
		this.accNum = accNum;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	public Person getAccHolder() {
		return accHolder;
	}
	public void setAccHolder(Person accHolder) {
		this.accHolder = accHolder;
	}
	
	abstract boolean withdraw(Double amount);
	public void deposit(double amount){
		this.setBalance(this.getBalance()+amount);
	}
	@Override
	public String toString() {
		return "Account [accNum=" + accNum + ", balance=" + balance
				+ ", accHolder=" + accHolder + "]";
	}
	
}
