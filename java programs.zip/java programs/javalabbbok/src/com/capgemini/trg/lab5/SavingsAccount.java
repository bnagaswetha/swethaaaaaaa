package com.capgemini.trg.lab5;

public class SavingsAccount extends Account{
	

	private final int minimumbalance=1000;

	public SavingsAccount() {
		super();
		// TODO Auto-generated constructor stub
	}

	public SavingsAccount(long accNum, double balance, Person accHolder) {
		super(balance, accHolder);
		// TODO Auto-generated constructor stub
	}
	@Override
	public boolean withdraw(Double amount) {
		if(this.getBalance()<minimumbalance){
			System.out.println("No balance amount in your SB account");
			return false;
		}
		else if(this.getBalance()<minimumbalance){
			System.out.println("Insufficient funds in your SB account");
			
			return false;
		}
		else if((this.getBalance()-amount)<minimumbalance){
			System.out.println("Minimum balance 1000 should be maintained in your SB account");
			//this.setBalance(this.getBalance()-amount);
			return false;
			
		}
		
		else{
			this.setBalance(this.getBalance()-amount);
			return true;
		}
			
		
	}
	
}
