package com.capgemini.trg.lab5;

public class CurrentAccount extends Account{
	

	public CurrentAccount() {
		super();
		// TODO Auto-generated constructor stub
	}

	public CurrentAccount(double balance, Person accHolder) {
		super(balance, accHolder);
		// TODO Auto-generated constructor stub
	}
	@Override
	public boolean withdraw(Double amount) {
		if(this.getBalance()<0.0){
			System.out.println("No balance amount in your SB account");
			return false;
		}
		else if(this.getBalance()<amount){
			System.out.println("Insufficient funds in your SB account");
			
			return false;
		}
		
			
		
		else{
			this.setBalance(this.getBalance()-amount);
			return true;
		}
	}

}
