package com.capgemini.trg.lab5;

import java.time.LocalDate;


public class AccountTester {

	public static void main(String[] args) {
		Person p1=new Person("Smith",44.0f);
		Person p2=new Person("Kathy",44.0f);
		
		CurrentAccount account1=new CurrentAccount(2000.00,p1);
		Account account2=new CurrentAccount(3000.00,p2);
		System.out.println(account1);
		System.out.println(account2);
		if(account2.withdraw(1500.00)){
			System.out.println("Withdraw successfull");
		}else{
			System.out.println("Withdraw cannot possible");
		}
		System.out.println("remaining balance:"+account2.getBalance());
	}

}
