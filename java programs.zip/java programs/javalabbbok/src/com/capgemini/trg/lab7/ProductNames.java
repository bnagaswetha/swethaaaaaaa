package com.capgemini.trg.lab7;

import java.util.Arrays;
import java.util.Scanner;

public class ProductNames {
	private static Scanner sc=new Scanner(System.in);
	public static void main(String[] args) {



		System.out.println("Enter number of products: ");
		int size=sc.nextInt();
		String names[]=new String[size];
		sc.nextLine();//to clear KBD line
		//System.out.println(names.length);
		getProductNames(names);
		showProductNames(names);
		Arrays.sort(names);
		System.out.println("After sorting:");
		showProductNames(names);

	}

	private static void showProductNames(String[] names) {
		//for loop
		for (int i=0;i<names.length;i++){
			System.out.println("student "+(i+1)+" : "+names[i]);

		}
		/*//for each loop

				for(String i:names){
					System.out.println("product "+(i+1)+" : "+i);
				}*/
	}

	private static void getProductNames(String[] names) {
		for (int i=0;i<names.length;i++){
			System.out.println("enter product "+(i+1)+" : ");
			names[i]=new String(sc.nextLine());

		}

	}



}
