package com.capgemini.trg.lab7;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

public class ProductNamesArrayList {

	public static void main(String[] args) {
		List<String> productNames=new ArrayList<>();
		getProductNames(productNames);
		System.out.println("Before sorting:");
		displayProductNames(productNames);
		Collections.sort(productNames);
		System.out.println("After sorting:");
		displayProductNames(productNames);
		

	}

	private static void displayProductNames(List<String> productNames) {
		System.out.println("Products are:");
		for(String s:productNames){
			System.out.println(s);
		}
		
	}

	private static void getProductNames(List<String> productNames) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter number of products");
		int n=sc.nextInt();
		for(int i=0;i<n;i++){
			System.out.println("product "+(i+1)+": ");
			productNames.add(sc.next());
		}
		
		
	}

}
