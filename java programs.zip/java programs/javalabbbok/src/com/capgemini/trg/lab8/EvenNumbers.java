package com.capgemini.trg.lab8;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class EvenNumbers {

	public static void main(String[] args) {
		writeToFile();
		readFromFile();

	}
	private static void readFromFile() {
		File file=new File("D:\\data\\numbers.txt");
		if(file.exists() && file.canRead()){
			try{
				Scanner scanner=new Scanner(file);
				scanner.useDelimiter(",");
				System.out.println("Even numbers in the file are:");
				while(scanner.hasNext()){
					int number=scanner.nextInt();
					if(number%2==0){
						System.out.println(number);
					}
				}
				
			}catch(FileNotFoundException e){
				e.printStackTrace();
			}
		}
		
	}
	private static void writeToFile() {

		try(
				FileWriter fw=new FileWriter("D:\\Data\\numbers.txt");
				BufferedWriter bw=new BufferedWriter(fw);
				

				){
			
				bw.write("0,1,2,3,4,5,6,7,8,9,10");
			

		}catch(IOException e){
			e.printStackTrace();

		}catch(Exception e){
			e.printStackTrace();

		}
	}

}
