package com.capgemini.trg.lab8;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.LineNumberReader;
import java.io.PrintWriter;

public class ReverseFile {

	public static void main(String[] args) {
		File file=new File("D:\\Data\\read.txt");
		StringBuffer sb=(readFromFile(file));
		//System.out.println(sb);
		File revfile=new File("D:\\Data\\reversed.txt");
		writeToFile(sb,revfile);
		
	
		
		

	}
	private static StringBuffer readFromFile(File file) {
		System.out.println("data in read.txt:");
		System.out.println("---------");
		try(
				FileReader fr=new FileReader(file);
				BufferedReader br=new BufferedReader(fr);
				LineNumberReader lr=new LineNumberReader(br);

				){

			String line;
			
			StringBuffer sb1=new StringBuffer();
			while((line=lr.readLine())!=null){
				
				System.out.println(line);
				sb1.append(line);

			}
			
			sb1=sb1.reverse();
			//System.out.println(sb1);
			return sb1;

		}

		catch(IOException e){
			e.printStackTrace();

		}catch(Exception e){
			e.printStackTrace();

		}
		return null;
	}
	private static void writeToFile(StringBuffer sb,File file) {
		

		try(
				FileWriter fw=new FileWriter(file);
				BufferedWriter bw=new BufferedWriter(fw);
				PrintWriter pw=new PrintWriter(fw);
				


				){
			
				pw.print(sb.toString());
				pw.println();
			

		}catch(IOException e){
			e.printStackTrace();

		}catch(Exception e){
			e.printStackTrace();

		}
	}

}
