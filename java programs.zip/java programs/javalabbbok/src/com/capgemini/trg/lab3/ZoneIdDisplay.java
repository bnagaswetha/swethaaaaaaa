package com.capgemini.trg.lab3;

import java.time.LocalDate;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.Scanner;

public class ZoneIdDisplay {

	public static void main(String[] args) {
		System.out.println("Enter your zone id");
		Scanner sc=new Scanner(System.in);
		String s=sc.next();
		display(s);
	
		

	}

	private static void display(String zoneId) {
		
	
		ZonedDateTime t=ZonedDateTime.now(ZoneId.of(zoneId));
		System.out.println(t);
			
	
	

	}

}
