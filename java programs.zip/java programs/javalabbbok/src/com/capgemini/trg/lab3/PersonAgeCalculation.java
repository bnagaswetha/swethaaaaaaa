package com.capgemini.trg.lab3;

import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.time.format.FormatStyle;

public class PersonAgeCalculation {
	String firstname;
	String lastname;
	char gender;
	public PersonAgeCalculation(String fname,String lname,char gen){
		firstname=fname;
		lastname=lname;
		gender=gen;
	}
	public PersonAgeCalculation(){
		super();
	}
	

	public String getFirstname() {
		return firstname;
	}
	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}
	public String getLastname() {
		return lastname;
	}
	public void setLastname(String lastname) {
		this.lastname = lastname;
	}
	public char getGender() {
		return gender;
	}
	public void setGender(char gender) {
		this.gender = gender;
	}
	public void calculateAge(String age)
	{
		LocalDate today=LocalDate.now();
		DateTimeFormatter formatter=DateTimeFormatter.ofLocalizedDate(FormatStyle.LONG);
		formatter=DateTimeFormatter.ofPattern("dd-MM-yyyy");
		LocalDate date=LocalDate.parse(age,formatter);
		Period period=date.until(today);
		System.out.println("age: "+period.getYears());

	}
	public String getFullName(String firstName, String lastName){
		return firstName+" "+lastName;
		
	}
	

}
