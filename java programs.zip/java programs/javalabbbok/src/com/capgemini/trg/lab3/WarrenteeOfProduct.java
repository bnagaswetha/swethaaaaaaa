package com.capgemini.trg.lab3;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.FormatStyle;
import java.util.Scanner;

public class WarrenteeOfProduct {

	public static void main(String[] args) {
		System.out.println("Enter Product purchase date:");
		Scanner sc=new Scanner(System.in);
		String s1=sc.next();
		System.out.println("Enter warrentee period in months:");
		int mon=sc.nextInt();
		System.out.println("Enter warrentee period in years:");
		int year=sc.nextInt();
		productExpire(s1,mon,year);

	}

	private static void productExpire(String s, int mon, int year) {
		DateTimeFormatter formatter=DateTimeFormatter.ofLocalizedDate(FormatStyle.LONG);
		formatter=DateTimeFormatter.ofPattern("dd-MM-yyyy");
		LocalDate date=LocalDate.parse(s,formatter);
		int pdate=date.getDayOfMonth();
		int pmonth=date.getMonthValue();
		int pyear=date.getYear();
		
		if((pmonth+mon)<=12){
			
			System.out.println("Expiry date: "+pdate+"-"+(pmonth+mon)+"-"+(year+pyear));
		}
		else{
			
			System.out.println("Expiry date: "+pdate+"-"+((pmonth+mon)-12)+"-"+(year+pyear));

		}

		
	}

}
