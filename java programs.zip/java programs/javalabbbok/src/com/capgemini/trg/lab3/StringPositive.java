package com.capgemini.trg.lab3;

import java.util.Scanner;

public class StringPositive {

	public static void main(String[] args) {
		System.out.println("enter your string:");
		Scanner sc=new Scanner(System.in);
		String s=sc.nextLine();
		
		if(!positive(s))
		{
			System.out.println(s+" is not a positive string");
		}
		else{
			System.out.println(s+" is a positive string");
		}

	}

	private static boolean positive(String s) {
		
		for(int i=0;i<s.length()-1;i++){
			if(s.charAt(i)<s.charAt(i+1)){
				continue;
			}
			else
				return false;
		}
		
		return true;
	}

}
