package com.capgemini.trg.lab3;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.time.format.FormatStyle;
import java.util.Date;
import java.util.Scanner;

public class DateDuration {

	public static void main(String[] args) {
		System.out.println("Enter Date:");
		Scanner sc=new Scanner(System.in);
		String s=sc.next();
		duration(s);

	}

	private static void duration(String s) {
		
		LocalDate today=LocalDate.now();
		DateTimeFormatter formatter=DateTimeFormatter.ofLocalizedDate(FormatStyle.LONG);
		formatter=DateTimeFormatter.ofPattern("dd-MM-yyyy");
		LocalDate date=LocalDate.parse(s,formatter);
		Period period=date.until(today);
		System.out.println("The duartion from your entered date to today is:");
		System.out.println("years:"+period.getYears());
		System.out.println("months:"+period.getMonths());
		System.out.println("days:"+period.getDays());
	}

}
