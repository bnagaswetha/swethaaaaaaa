package com.capgemini.trg.lab3;

import java.util.Scanner;

public class StringOperations {

	public static void main(String[] args) {
		System.out.println("enter your string to perform operations:");
		Scanner sc=new Scanner(System.in);
		String s=sc.nextLine();
		System.out.println();
		System.out.println("1.add the string to itself");
		System.out.println("2.replace odd positions with #");
		System.out.println("3.remove duplicate characters in the string");
		System.out.println("4.change odd characters to upper case");
		System.out.println("select your operation");
		int choice=sc.nextInt();
		String output=operations(s,choice);
		System.out.println("output:"+output);
	}

	private static String operations(String s, int choice) {
		String out="";
		String temp="";
		switch(choice){
		case 1:out=s.concat(s);
		break;				
				
		case 2:
			for(int i=0;i<s.length();i++){
			if(i%2==0)
			{
				out+=s.charAt(i);
			}
			else{
				out+='#';
			}
			
			}
			break;
		
		case 3:
			for(int i=0;i<s.length();i++){
				temp=""+s.charAt(i);
				if(!(out.contains(temp))){
					out+=temp;
				}
				
			}
			break;
		case 4:
			for(int i=0;i<s.length();i++){
				if(i%2==0)
				{
					out+=s.charAt(i);
				}
				else{
					temp=""+s.charAt(i);
					out+=temp.toUpperCase();
				}
					
				}
			break;
		default:System.out.println("please enter valid option");
		
		}
		return out;
		
	}

}
