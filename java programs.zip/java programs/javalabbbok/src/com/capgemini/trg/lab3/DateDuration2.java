package com.capgemini.trg.lab3;

import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.time.format.FormatStyle;
import java.util.Scanner;

public class DateDuration2 {

	public static void main(String[] args) {
		System.out.println("Enter Date1:");
		Scanner sc=new Scanner(System.in);
		String s1=sc.next();
		System.out.println("Enter Date2:");
		String s2=sc.next();
		duration(s1,s2);

	}
private static void duration(String s1,String s2) {
		
		
		DateTimeFormatter formatter=DateTimeFormatter.ofLocalizedDate(FormatStyle.LONG);
		formatter=DateTimeFormatter.ofPattern("dd-MM-yyyy");
		LocalDate date1=LocalDate.parse(s1,formatter);
		LocalDate date2=LocalDate.parse(s2,formatter);
		Period period=date1.until(date2);
		System.out.println("The duartion between two dates is");
		System.out.println("years:"+period.getYears());
		System.out.println("months:"+period.getMonths());
		System.out.println("days:"+period.getDays());
	}

}
