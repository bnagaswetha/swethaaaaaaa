package com.capgemini.trg.lab3;

import com.capgemini.trg.lab2.Person;

public class PersonAgeCalculationMain {

	public static void main(String[] args) {
		PersonAgeCalculation ob=new PersonAgeCalculation("Divya","Bharathi",'F');
		System.out.println("Person Details:");
		System.out.println("_________________");
		System.out.println("First Name: "+ob.getFirstname());
		System.out.println("Last Name: "+ob.getLastname());
		System.out.println("Fullname: "+ob.getFullName(ob.getFirstname(), ob.getLastname()));
		System.out.println("Gender: "+ob.getGender());
		ob.calculateAge("02-06-1997");

	}

}
