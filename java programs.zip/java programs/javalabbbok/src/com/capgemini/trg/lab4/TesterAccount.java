package com.capgemini.trg.lab4;

public class TesterAccount {

	public static void main(String[] args) {
		Person p1=new Person("Smith",44.0f);
		Person p2=new Person("Kathy",45.0f);
		Account account1=new Account(2000.00,p1);
		Account account2=new Account(3000.00,p2);
		System.out.println(account1);
		System.out.println(account2);
		account1.deposit(2000);
		if(account2.withdraw(2000.00)){
			System.out.println("Withdraw successfull");
		}else{
			System.out.println("Withdraw cannot possible");
		}
		System.out.println("Smith balance:"+account1.getBalance());

		System.out.println("Kathy balance:"+account2.getBalance());

	}

}
