package com.capgemini.trg.lab4;

public class CurrentAccount extends Account{
	private final int overdraft_limit=1000;

	public CurrentAccount() {
		super();
		// TODO Auto-generated constructor stub
	}

	public CurrentAccount(double balance, Person accHolder) {
		super(balance, accHolder);
		// TODO Auto-generated constructor stub
	}
	@Override
	public boolean withdraw(Double amount) {
		if(amount>overdraft_limit){
			System.out.println("overdraft limit is 1000");
			return false;
		}
		
		else{
			this.setBalance(this.getBalance()-amount);
			return true;
		}
			
		
	}

}
