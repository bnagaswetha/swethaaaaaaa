package com.capgemini.trg.lab2;
import com.capgemini.trg.lab2.Gender;
public class Person3Main {

	public static void main(String[] args) {
		Person3 ob=new Person3("Divya","Bharathi",Gender.F,123456789);
		
		display(ob);

	}

	private static void display(Person3 ob) {
		System.out.println("Person Details:");
		System.out.println("_________________");
		System.out.println("First Name: "+ob.firstname);
		System.out.println("Last Name: "+ob.lastname);
		System.out.println("Gender: "+ob.gender);
		System.out.println("Phone Number: "+ob.number);
		
	}

}
