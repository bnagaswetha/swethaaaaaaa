package com.capgemini.trg.lab2;

public class Person {
	
	String firstname;
	String lastname;
	char gender;
	public Person(String fname,String lname,char gen){
		firstname=fname;
		lastname=lname;
		gender=gen;
	}
	public Person(){
		super();
	}
	

	public String getFirstname() {
		return firstname;
	}
	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}
	public String getLastname() {
		return lastname;
	}
	public void setLastname(String lastname) {
		this.lastname = lastname;
	}
	public char getGender() {
		return gender;
	}
	public void setGender(char gender) {
		this.gender = gender;
	}
	
}
