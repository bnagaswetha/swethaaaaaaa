package com.capgemini.trg.lab2;

public class PersonMain {

	public static void main(String[] args) {
		Person ob=new Person("Divya","Bharathi",'F');
		System.out.println("Person Details:");
		System.out.println("_________________");
		System.out.println("First Name: "+ob.firstname);
		System.out.println("Last Name: "+ob.lastname);
		System.out.println("Gender: "+ob.gender);

	}

}
