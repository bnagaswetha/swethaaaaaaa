package com.capgemini.trg.lab2;

public class PersonDetails {

	public static void main(String[] args) {
		
		System.out.println("Person Details:");
		System.out.println("_________________");
		System.out.println("First Name: Divya");
		System.out.println("Last Name: Bharathi");
		System.out.println("Gender: F");
		System.out.println("Age: 20");

	}

}
