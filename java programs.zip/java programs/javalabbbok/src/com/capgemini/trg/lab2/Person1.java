package com.capgemini.trg.lab2;

public class Person1 {
	String firstname;
	String lastname;
	char gender;
	int number;
	public Person1(String fname,String lname,char gen,int num){
		firstname=fname;
		lastname=lname;
		gender=gen;
		number=num;
		
	}
	public Person1(){
		super();
	}
	

	public String getFirstname() {
		return firstname;
	}
	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}
	public String getLastname() {
		return lastname;
	}
	public void setLastname(String lastname) {
		this.lastname = lastname;
	}
	public char getGender() {
		return gender;
	}
	public void setGender(char gender) {
		this.gender = gender;
	}

}
