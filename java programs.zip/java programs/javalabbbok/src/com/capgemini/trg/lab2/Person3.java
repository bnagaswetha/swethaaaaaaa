package com.capgemini.trg.lab2;



public class Person3 {
	Gender gender;
	String firstname;
	String lastname;
	
	int number;
	public Person3(String fname,String lname,Gender gen,int num){
		firstname=fname;
		lastname=lname;
		gender=gen;
		number=num;
		
	}
	public Person3(){
		super();
	}
	

	public String getFirstname() {
		return firstname;
	}
	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}
	public String getLastname() {
		return lastname;
	}
	public void setLastname(String lastname) {
		this.lastname = lastname;
	}
	public Gender getGender() {
		return gender;
	}
	public void setGender(Gender gender) {
		this.gender = gender;
	}
	public int getNumber() {
		return number;
	}
	public void setNumber(int number) {
		this.number = number;
	}
	
}
