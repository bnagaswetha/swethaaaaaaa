package com.capgemini.trg.lab2;

public class Person1Main {

	public static void main(String[] args) {
		Person1 ob=new Person1("Divya","Bharathi",'F',123456789);
		
		display(ob);

	}

	private static void display(Person1 ob) {
		System.out.println("Person Details:");
		System.out.println("_________________");
		System.out.println("First Name: "+ob.firstname);
		System.out.println("Last Name: "+ob.lastname);
		System.out.println("Gender: "+ob.gender);
		System.out.println("Phone Number: "+ob.number);
		
	}

}
