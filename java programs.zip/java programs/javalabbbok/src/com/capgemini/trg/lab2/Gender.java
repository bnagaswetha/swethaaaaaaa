package com.capgemini.trg.lab2;

public enum Gender {
	M,F

}
