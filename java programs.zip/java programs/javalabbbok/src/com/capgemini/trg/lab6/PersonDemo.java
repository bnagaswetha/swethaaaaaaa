package com.capgemini.trg.lab6;

import java.util.Scanner;

public class PersonDemo {
	private String fname;
	private String lname;
	
	public void getUserDetails(Person1 ob) throws CredentialException{
		if(ob.firstname=="" &&ob.lastname==""){
			throw new CredentialException(ob.getFirstname(),ob.getLastname());
		}
		
		
		System.out.println("Person Details:");
		System.out.println("_________________");
		System.out.println("First Name: "+ob.firstname);
		System.out.println("Last Name: "+ob.lastname);
		System.out.println("Gender: "+ob.gender);
		System.out.println("Phone Number: "+ob.number);
	}
	
}
