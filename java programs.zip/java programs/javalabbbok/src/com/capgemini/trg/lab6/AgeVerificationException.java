package com.capgemini.trg.lab6;

public class AgeVerificationException extends Exception {
	private float age;

	public AgeVerificationException(float age) {
		super();
		this.age = age;
	}

	public float getAge() {
		return age;
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return super.toString()+"Age of a person should be above 15";
	}

	
}
