package com.capgemini.trg.lab6;

public class Account {
	private long accNum;
	private double balance;
	private Person accHolder;
	static int acno=1000;
	public Account() {
		super();
	}
	public Account(double balance, Person accHolder) {
		super();
		acno+=1;
		this.accNum = acno;
		this.balance = balance;
		this.accHolder = accHolder;
	}
	public long getAccNum() {
		return accNum;
	}
	public void setAccNum(long accNum) {
		this.accNum = accNum;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	public Person getAccHolder() {
		return accHolder;
	}
	public void setAccHolder(Person accHolder) {
		this.accHolder = accHolder;
	}
	public boolean withdraw(Double amount) {
		if(this.getBalance()<0.0){
			System.out.println("No balance amount in your SB account");
			return false;
		}
		else if(this.getBalance()<amount){
			System.out.println("Insufficient funds in your SB account");
			
			return false;
		}
		
			
		
		else{
			this.setBalance(this.getBalance()-amount);
			return true;
		}
			
		
	}
	public void deposit(double amount){
		this.setBalance(this.getBalance()+amount);
		System.out.println(this.getAccNum()+" balance is:"+this.getBalance());
	}
	@Override
	public String toString() {
		return "Account [accNum=" + accNum + ", balance=" + balance
				+ ", accHolder=" + accHolder + "]";
	}
	public void getDetails(Account ac) throws AgeVerificationException{
		if(ac.getAccHolder().getAge()<15){
			throw new AgeVerificationException(ac.getAccHolder().getAge());
		}
		
		
		System.out.println(ac);
		
	}
	
}
