package com.capgemini.trg.lab6;

public class Person1Main {

	public static void main(String[] args) {
		Person1 ob=new Person1("","",'F',123456789);
		PersonDemo user=new PersonDemo();
		try {
			user.getUserDetails(ob);
		} catch (CredentialException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println("you must give firstname and lastname");
		}

		

	}

	

}
