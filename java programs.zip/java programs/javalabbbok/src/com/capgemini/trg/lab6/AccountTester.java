package com.capgemini.trg.lab6;

import java.util.Scanner;


public class AccountTester {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		Person p1=new Person("Smith",4.0f);
		Person p2=new Person("Kathy",45.0f);
		System.out.println("Choose options:\n 1.SavingsAccount \n2.CurrentAccount");
		int ch=sc.nextInt();
		switch(ch){
		case 1:
			Account account1=new SavingsAccount(2000.00,p1);
			Account account2=new SavingsAccount(3000.00,p2);
			System.out.println(account1);
			System.out.println(account2);
			account1.deposit(2000);
			if(account2.withdraw(3000.00)){
				System.out.println("Withdraw successfull");
			}else{
				System.out.println("Withdraw cannot possible");
			}
			System.out.println(account2.getBalance());
			break;
		case 2:
			Account account3=new CurrentAccount(2000.00,p1);
			Account account4=new CurrentAccount(3000.00,p2);
			try {
				account3.getDetails(account3);
			} catch (AgeVerificationException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				System.out.println("you must give age >15");
			}
			try {
				account4.getDetails(account4);
			} catch (AgeVerificationException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				System.out.println("you must give age >15");
			}
			if(account4.withdraw(2500.00)){
				System.out.println("Withdraw successfull");
			}else{
				System.out.println("Withdraw cannot possible");
			}
			System.out.println(account4.getBalance());
			break;
		}
		
	}

}
