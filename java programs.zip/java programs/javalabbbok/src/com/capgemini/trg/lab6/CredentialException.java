package com.capgemini.trg.lab6;

public class CredentialException extends Exception{
	private String fname;
	private String lname;
	public CredentialException(String fname, String lname) {
		super();
		this.fname = fname;
		this.lname = lname;
	}
	@Override
	public String toString() {
		return super.toString()+"name cannot be blank";
	}
	
	
	

}
