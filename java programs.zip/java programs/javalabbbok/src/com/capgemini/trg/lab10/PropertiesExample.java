package com.capgemini.trg.lab10;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Properties;

public class PropertiesExample {

	
		private static Properties properties=new Properties();
		static{
			properties.setProperty("FirstName", "naga");
			properties.setProperty("LastName", "swetha");
			properties.setProperty("Gender", "Female");
			properties.setProperty("Age", "21");
			properties.setProperty("Id", "12345678");
		}
		public static void  saveProperties(String fileName){
			try(
					FileOutputStream fos=new FileOutputStream(fileName);
					){
				properties.store(fos,"PersonDetails Property file");
				System.out.println("Property file created");
			}catch(IOException e){
				e.printStackTrace();
			}catch(Exception e){
				e.printStackTrace();
			}
		}
		public  static Properties loadProperties(String fileName){

			File file=new File(fileName);
			if(file.exists() && file.canRead()){
				try(
						FileInputStream fis=new FileInputStream(fileName);
						){
					Properties properties=new Properties();
					properties.load(fis);
					
					return properties;
				}catch(IOException e){
					e.printStackTrace();
				}catch(Exception e){
					e.printStackTrace();
				}
				return null;
			}
			else{
				System.out.println("Unable to open the file");
				return null;
			}

		}


	

}
