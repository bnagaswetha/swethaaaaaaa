package com.capgemini.trg.lab10;

import java.util.Properties;

public class PropertiesTester {
	public static void main(String[] args) {
		String fileName="D:\\data\\PersonProperties.properties";
		PropertiesExample.saveProperties(fileName);
	Properties properties=PropertiesExample.loadProperties(fileName);
		properties.list(System.out);

	}


}
