package com.capgemini.trg.lab10;

import java.util.Properties;

public class PropertiesTester1 {
	public static void main(String[] args) {
		String fileName="D:\\data\\PersonProperties.properties";
		PropertiesExample.saveProperties(fileName);
		Properties properties=PropertiesExample.loadProperties(fileName);
		
		System.out.println("FirstName: "+properties.getProperty("FirstName"));
		System.out.println("LastName: "+properties.getProperty("LastName"));
		System.out.println("Gender: "+properties.getProperty("Gender"));
		System.out.println("Age: "+properties.getProperty("Age"));
		System.out.println("Id: "+properties.getProperty("Id"));

	}


}
