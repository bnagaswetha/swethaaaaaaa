package com.capgemini.trg.lab10;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Employee {
	public static void main(String[] args) {
		createEmp();
		//addEmp();
		//displayEmp();
		//deleteEmp();
		//displayEmp();

	}

	private static void displayEmp() {
		String sql = "select * from EmployeeTable";
		try(
				Connection connection=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","hr","India123");
				PreparedStatement preparedStatement=connection.prepareStatement(sql);
				){


			ResultSet resultSet=preparedStatement.executeQuery();
			if(!resultSet.next()){
				System.out.println("There is no data in the table");
			}else{
				do{
					listEmp(resultSet);

				}while(resultSet.next());
			}
		}catch(SQLException e){
			e.printStackTrace();

		}catch(Exception e){
			e.printStackTrace();
		}



	}
	private static void listEmp(ResultSet resultSet) {
		try {
			System.out.println("EmpNo: "+resultSet.getInt("empno"));
			System.out.println("Employee name: "+resultSet.getString(2));
			System.out.println("Designation: "+resultSet.getString(3));
			System.out.println("Salary: "+resultSet.getDouble(4));
			System.out.println("Insurance Scheme: "+resultSet.getString(5));

			System.out.println("----------------");

		} catch (SQLException e) {

			e.printStackTrace();
		}

	}

	private static void deleteEmp() {
		String sql="delete from EmployeeTable where empno=?";
		try(Connection connection=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","hr","India123");
				PreparedStatement preparedStatement=connection.prepareStatement(sql);

				){
			preparedStatement.setInt(1, 3);
			int n=preparedStatement.executeUpdate();
			if(n>0){
				System.out.println("1 row was deleted from table");
			}else{
				System.out.println("unable to delete data");
			}
		}catch(SQLException e){
			e.printStackTrace();

		}catch(Exception e){
			e.printStackTrace();
		}
	}

	private static void addEmp() {
		String sql="insert into EmployeeTable(empno,ename,designation,sal,insurance_scheme) values(?,?,?,?,?)";
		try(Connection connection=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","hr","India123");
				PreparedStatement preparedStatement=connection.prepareStatement(sql);

				){
			preparedStatement.setInt(1, 101);
			preparedStatement.setString(2,"Smith");
			preparedStatement.setString(3, "Clerk");
			preparedStatement.setDouble(4, 5000.00);
			preparedStatement.setString(5,"Noscheme");

			int n=preparedStatement.executeUpdate();
			if(n>0){
				System.out.println("1 row was inserted in the table");
			}else{
				System.out.println("Unable to insert the data into the table");
			}

		}catch(SQLException e){
			e.printStackTrace();

		}catch(Exception e){
			e.printStackTrace();
		}

	}

	private static void createEmp() {
		String sql="create table EmployeeTable(empno integer primary key,ename varchar(20),"
				+ "designation varchar(30) check(designation IN('SystemAssociate','Programmer','Manager','Clerk')),salary number(10,2),"
				+ "insurance_scheme varchar(9) check(insurance_scheme IN('A','B','C','Noscheme')))";
		try(
				Connection connection =DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","hr","India123");
				Statement statement = connection.createStatement();
				){
			statement.executeQuery(sql);
			System.out.println("Employee Table was created...");

		}catch(SQLException e){
			e.printStackTrace();
		}catch(Exception e){
			e.printStackTrace();
		}
	}


}
