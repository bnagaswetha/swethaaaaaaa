package com.capgemini.trg.ui;

import java.time.LocalDate;
import java.util.Arrays;

import com.capgemini.trg.service.Customer;
import com.capgemini.trg.service.CustomerBirthDateComparator;

public class CustomerTester {

	public static void main(String[] args) {
		Customer customers[]=new Customer[4];
		populateCustomers(customers);
		showCustomers(customers);
		Arrays.sort(customers);
		//sorting based on non key attribute customer name
		//Arrays.sort(customers,new CustomerNameComparator());
		//sorting based on birthdate
		//Arrays.sort(customers,new CustomerBirthDateComparator());
		System.out.println("after sorting:");
		showCustomers(customers);

	}

	private static void populateCustomers(Customer[] customers) {
		customers[0]=new Customer(1002,"Smith",LocalDate.of(1998,12,7),"Hyderabad",
										573453845L,"smith@gmail.com","smith98");
		customers[1]=new Customer(1001,"Jake",LocalDate.of(1997,2,17),"Chennai",
				5734535L,"jake@gmail.com","jake98");
		customers[2]=new Customer(1004,"Mohan",LocalDate.of(1988,6,9),"Pune",
				57333845L,"Mohan@gmail.com","mohan8");
		customers[3]=new Customer(1003,"Pk",LocalDate.of(1996,7,22),"Delhi",
				873453845L,"pk@gmail.com","pk6");
		
	}

	private static void showCustomers(Customer[] customers) {
	
		System.out.println("Customer Details..");
		for(Customer c:customers){
			System.out.println(c);
		}
		
	}

}
