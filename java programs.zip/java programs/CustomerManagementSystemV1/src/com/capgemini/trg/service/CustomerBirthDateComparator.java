package com.capgemini.trg.service;

import java.util.Comparator;

public class CustomerBirthDateComparator implements Comparator<Customer>{

	@Override
	public int compare(Customer o1, Customer o2) {
		
		return o1.getBirthdate().compareTo(o2.getBirthdate());
	}
	

}
