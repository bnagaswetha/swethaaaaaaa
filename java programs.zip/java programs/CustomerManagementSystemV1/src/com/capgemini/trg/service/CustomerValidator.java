package com.capgemini.trg.service;

import java.util.regex.Pattern;

/**
 * 
 * @author nbandamr
 * This class validates the data fields of Customer class
 */
public class CustomerValidator {
	/**
	 * @param customer
	 * @return false if customer is not a 5-digit integer
	 * return true if customer is a 5-digit integer 
	 */
		
	public Boolean isValidCustomerId(Customer customer){
		String regex="^[0-9] {5}$";
		String customerid=customer.getCustomerid().toString();
		//Pattern pattern=Pattern.compile(regex);
		//return customerid.matches(regex);
		return Pattern.matches(regex,customerid);
		
	}
	/**
	 * @param customer
	 * @return true if customer name is a sequence of alphabets
	 * return false one or more spaces 
	 */
	public Boolean isValidCustomerName(Customer customer){
		String regex="^[a-zA-Z](.)?([a-zA-Z]+)?(\\s)?([a-zA-Z]+)?$";
		return Pattern.matches(regex,customer.getCustomerName());
	}
	/**
	 * @param customer
	 * @return true if birthdate is less by atleast 10 years from current date
	 * 
	 */
	public Boolean isValidBirthdate(Customer customer){
		
		return false;
	}
	/**
	 * @param customer
	 * @return true if email is valid else return false
	 * email validuty:
	 * 1.email begins with either digits or alphabets followed one @ symbol followed by domain name 
	 * 		followed by dot(.)
	 * operator followed by 2 or 3 characters followed by dot(.) operator followed by 2 characters.
	 * The second dot operator followed by 2 characters is optional. 
	 * 
	 */
	public Boolean isValidEmail(Customer customer){
		return false;
	}
	/**
	 * @param customer
	 * @return true if mobile number is 10-digit number
	 * else return false
	 * 
	 */
	public Boolean isValidMobile(Customer customer){
		String mobile=customer.getMobile().toString();
		String regex="^[1-9][0-9]{9}$";
		return Pattern.matches(regex,mobile);
	}
	/**
	 * @param customer
	 * @return true or false
	 * invoke above 4 methods in this method ,return false
	 * if any of these methods return false else return true
	 * 
	 */
	public Boolean isValidCustomer(Customer customer){
		return false;
	}
}
