package com.capgemini.trg.ui;

import java.util.regex.Pattern;

public class Tester {

	public static void main(String[] args) {
		String regex="^[a-zA-Z]+(\\s?[a-zA-Z]+)$";
		String name="gde475ejkhy  ";
		System.out.println(Pattern.matches(regex,name));

	}

}
