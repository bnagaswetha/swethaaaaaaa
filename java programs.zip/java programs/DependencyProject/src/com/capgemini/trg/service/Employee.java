package com.capgemini.trg.service;

public class Employee {
	private Integer empid;
	private String ename;
	public Employee(){
		
	}
	public Employee(Integer empid, String ename) {
		super();
		this.empid = empid;
		this.ename = ename;
	}
	public Integer getEmpid() {
		return empid;
	}
	public void setEmpid(Integer empid) {
		this.empid = empid;
	}
	public String getEname() {
		return ename;
	}
	public void setEname(String ename) {
		this.ename = ename;
	}
	public Boolean login(SwipeCard swipecard){
		if(swipecard.swipe(this)){
			return true;
		}
		return false;
	}

}
