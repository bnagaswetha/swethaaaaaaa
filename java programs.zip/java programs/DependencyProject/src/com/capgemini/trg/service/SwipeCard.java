package com.capgemini.trg.service;

import java.time.LocalDate;

public class SwipeCard {
	private String code;
	private LocalDate expiryDate;
	public SwipeCard(){
		
	}
	public SwipeCard(String code, LocalDate expiryDate) {
		super();
		this.code = code;
		this.expiryDate = expiryDate;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public LocalDate getExpiryDate() {
		return expiryDate;
	}
	public void setExpiryDate(LocalDate expiryDate) {
		this.expiryDate = expiryDate;
	}
	public Boolean swipe(Employee e){
		String empid=e.getEmpid().toString();
		LocalDate today=LocalDate.now();
		if(today.isBefore(this.expiryDate) &&this.code.contains(empid)){
			return true;
		}
		return false;
	}

}
