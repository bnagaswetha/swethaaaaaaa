package com.capgemini.trg.ui;

import java.time.LocalDate;

import com.capgemini.trg.service.Employee;
import com.capgemini.trg.service.SwipeCard;

public class DependencyTester {

	public static void main(String[] args) {
		SwipeCard card=new SwipeCard("1234567",LocalDate.of(2017,12,30));
		Employee employee=new Employee(567,"aaa");
		if(employee.login(card)){
			System.out.println("welcome to capgemini");
		}
		else{
			System.out.println("unable to login");
		}

	}

}
