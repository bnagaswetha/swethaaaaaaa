package com.capgemini.trg.service;

import java.time.LocalDate;
import java.time.Period;

public class FixedDepositAccount extends Account {
	private LocalDate accountClosingDate;
	private Double finalFdAmount;
	
	
	public FixedDepositAccount() {
		
	}
	
	public FixedDepositAccount(Long accountNumber, String accountHolder,
			LocalDate accountOpeningDate, Double balance,
			LocalDate accountClosingDate) {
		super(accountNumber, accountHolder, accountOpeningDate, balance);
		this.accountClosingDate = accountClosingDate;
		this.calculateFinalFdAmount();
	}

	private void calculateFinalFdAmount(){
		Period period=accountClosingDate.until(this.getAccountOpeningDate());
		int years=period.getYears();
		if(years==1){
			this.finalFdAmount=this.getBalance()+7.25/100*this.getBalance();
			
		}
		else if(years==2){
			this.finalFdAmount=this.getBalance()+15/100*this.getBalance();
		}
		else if(years<=3){
			this.finalFdAmount=this.getBalance()+(7.75*3)/100*this.getBalance();
		}
		else {
			this.finalFdAmount=this.getBalance()+(8*years)/100*this.getBalance();
		}
	}

	public LocalDate getAccountClosingDate() {
		return accountClosingDate;
	}

	public Double getFinalFdAmount() {
		return finalFdAmount;
	}

	@Override
	public String toString() {
		return "FixedDepositAccount Details..."+"\n"+
				super.toString()+"\n"+
	"[accountClosingDate=" + accountClosingDate
				+ ", finalFdAmount=" + finalFdAmount + "]";
	}
	

}
