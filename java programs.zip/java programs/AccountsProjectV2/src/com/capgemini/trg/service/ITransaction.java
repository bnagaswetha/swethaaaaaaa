package com.capgemini.trg.service;

public interface ITransaction {
	public abstract Double withdraw(Double amount);
	public abstract void deposit(Double amount);

}
