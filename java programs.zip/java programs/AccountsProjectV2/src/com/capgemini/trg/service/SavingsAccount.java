package com.capgemini.trg.service;

import java.time.LocalDate;

public class SavingsAccount extends Account implements ITransaction{
	private static final Double RATE_OF_INTEREST=1.8;
	private String houseAddress;
	public SavingsAccount() {
		
	}
	public SavingsAccount(Long accountNumber, String accountHolder,
			LocalDate accountOpeningDate, Double balance, String houseAddress) {
		super(accountNumber, accountHolder, accountOpeningDate, balance);
		this.houseAddress = houseAddress;
	}
	
	public String getHouseAddress() {
		return houseAddress;
	}
	public void setHouseAddress(String houseAddress) {
		this.houseAddress = houseAddress;
	}
	
	@Override
	public String toString() {
		return "SavingsAccount Details..\n"+
	super.toString()+"\n"+
	"[houseAddress=" + houseAddress;
	}
	@Override
	public Double withdraw(Double amount) {
		if(this.getBalance()<0.0){
			System.out.println("No balance amount in your SB account");
			return -1.0;
		}
		else if(this.getBalance()<amount){
			System.out.println("Insufficient funds in your SB account");
			
			return 0.0;
		}
		else if((this.getBalance()-amount)<1000){
			System.out.println("Minimum balance 1000 should be maintained in your SB account");
			this.setBalance(this.getBalance()-amount);
			return amount;
			
		}
		
		else{
			this.setBalance(this.getBalance()-amount);
			return amount;
		}
			
		
	}
	@Override
	public void deposit(Double amount) {
		this.setBalance(this.getBalance()+amount);
		
	}
	
	

}
