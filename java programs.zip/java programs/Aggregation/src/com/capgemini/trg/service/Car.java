package com.capgemini.trg.service;

public class Car {
	private String manufacturer;
	private String model;
	private Engine engine;
	public Car() {
		super();
	}
	public Car(String manufacturer, String model, Engine engine) {
		super();
		this.manufacturer = manufacturer;
		this.model = model;
		this.engine = engine;
	}
	@Override
	public String toString() {
		return "Car [manufacturer=" + manufacturer + ", model=" + model
				+ ", engine=" + engine + "]";
	}
	public String getManufacturer() {
		return manufacturer;
	}
	public void setManufacturer(String manufacturer) {
		this.manufacturer = manufacturer;
	}
	public String getModel() {
		return model;
	}
	public void setModel(String model) {
		this.model = model;
	}
	public Engine getEngine() {
		return engine;
	}
	public void setEngine(Engine engine) {
		this.engine = engine;
	}
		
}
