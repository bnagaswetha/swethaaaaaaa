package com.capgemini.trg.ui;

import com.capgemini.trg.service.Car;
import com.capgemini.trg.service.Engine;

public class CarTester {

	public static void main(String[] args) {
		Engine engine=new Engine(12345679L,3.2,75);
		Car car=new Car("Maruthi","Swift DZire",engine);
		engine=null;
		System.out.println(car);
		//Aggregation :extracting Engine object before destroying car object
		Engine myengine=car.getEngine();
		car=null;//destroying car object
		System.out.println(myengine);

	}

}
