package com.capgemini.trg.ui;

import java.util.Arrays;
import java.util.Scanner;

public class StudentsNameDemo {
	private static Scanner sc=new Scanner(System.in);

	public static void main(String[] args) {
		System.out.println("Enter number of students: ");
		int size=sc.nextInt();
		String names[]=new String[size];
		sc.nextLine();//to clear KBD line
		//System.out.println(names.length);
		getStudentNames(names);
		showStudentNames(names);
		Arrays.sort(names);
		System.out.println("After sorting:");
		showStudentNames(names);

	}

	private static void showStudentNames(String[] names) {
		//for loop
		/*for (int i=0;i<names.length;i++){
			System.out.println("student "+(i+1)+" : "+names[i]);
			
		}*/
		//for each loop
		
		for(String i:names){
			System.out.println("student "+(i+1)+" : "+i);
		}
	}

	private static void getStudentNames(String[] names) {
		for (int i=0;i<names.length;i++){
			System.out.println("enter student "+(i+1)+" : ");
			names[i]=new String(sc.nextLine());
			
		}
		
	}

}
