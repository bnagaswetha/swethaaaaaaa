package com.capgemini.trg.ui;

public class VargsDemo {

	public static void main(String[] args) {
		new VargsDemo().showValues("a","b");
		new VargsDemo().showValues("a","b","c");

	}
	//elipse operator ...
	private void showValues(String ...strings ) {
		for(String s:strings){
			System.out.print(s);
		}
		System.out.println();
	}

	/*private void showValues(String string, String string2, String string3) {
		System.out.println(string+","+string2+","+string3);
	}

	private void showValues(String string, String string2) {
		System.out.println(string+","+string2);
		
	}*/
	

}
