package com.capgemini.trg.ui;

import com.capgemini.trg.service.Car;

public class CarTester {

	public static void main(String[] args) {
		Car car=new Car("Maruthi","Swift DZire",12345679L,3.2,75);
		System.out.println(car);
		//composition : along with car object engine object also destroyed.engine object cannot retrieved 
		//before destroying car object
		car=null;//car is destroyed
		

	}

}
