package com.capgemini.trg.service;

public class Engine {
	private Long serialNumber;
	private Double capacity;
	private Integer power;
	public Engine(){
		
	}
	public Engine(Long serialNumber, Double capacity, Integer power) {
		super();
		this.serialNumber = serialNumber;
		this.capacity = capacity;
		this.power = power;
	}
	public Long getSerialNumber() {
		return serialNumber;
	}
	public void setSerialNumber(Long serialNumber) {
		this.serialNumber = serialNumber;
	}
	public Double getCapacity() {
		return capacity;
	}
	public void setCapacity(Double capacity) {
		this.capacity = capacity;
	}
	public Integer getPower() {
		return power;
	}
	public void setPower(Integer power) {
		this.power = power;
	}
	

}

