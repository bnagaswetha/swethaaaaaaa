package com.capgemini.trg.service;

public class Car {
	private String manufacturer;
	private String model;
	private Engine engine;
	public Car() {
		super();
	}
	public Car(String manufacturer, String model,Long serialNumber,Double capacity, Integer power) {
		super();
		this.manufacturer = manufacturer;
		this.model = model;
		this.engine=new Engine(serialNumber,capacity,power);
	}
	public String getManufacturer() {
		return manufacturer;
	}
	public void setManufacturer(String manufacturer) {
		this.manufacturer = manufacturer;
	}
	public String getModel() {
		return model;
	}
	public void setModel(String model) {
		this.model = model;
	}
	@Override
	public String toString() {
		return "Car [manufacturer=" + manufacturer + ", model=" + model
				+ ", engine=" + engine + "]";
	}
	
	

}
