package com.capgemini.trg.ui;

import com.capgemini.trg.service.HelloThread;

public class HelloThreadTester {

	public static void main(String[] args) {
		Thread t1=new HelloThread();
		
		t1.start();
		try{
			Thread.sleep(100);
		}catch(InterruptedException e){
			e.printStackTrace();
		}
		
		System.out.println(Thread.currentThread());
		System.out.println("end of main() method");
	}

}
