package com.capgemini.trg.service;

public class MyRunnable implements Runnable{
	private static StringBuilder object=new StringBuilder("Welcome");

	@Override
	public void run() {
		int length=object.length();
		synchronized(this){
			for(int i=1;i<=length;i++){
				System.out.println(Thread.currentThread().getName()+":"+object.append('X'));
				
			}
		}
		
		
	}

	/*//synchronized method
	
	 * (non-Javadoc)
	 * @see java.lang.Runnable#run()
	 
	@Override
	public synchronized void run() {
		int length=object.length();
		for(int i=1;i<=length;i++){
			System.out.println(Thread.currentThread().getName()+":"+object.append('X'));
			
		}
		
	}*/

	/*@Override
	public void run() {
		int length=object.length();
		for(int i=1;i<=length;i++){
			System.out.println(Thread.currentThread().getName()+":"+object.append('X'));
			
		}
		
	}*/

}
