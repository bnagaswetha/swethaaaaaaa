package com.capgemini.trg.service;

public class HelloRunnable implements Runnable {

	@Override
	public void run() {
		System.out.println(Thread.currentThread());
		try{
			Thread.sleep(1000);
		}catch(InterruptedException e){
			e.printStackTrace();
		}
		
	}
	

}
