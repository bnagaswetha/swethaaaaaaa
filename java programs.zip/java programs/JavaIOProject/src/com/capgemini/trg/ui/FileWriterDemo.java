package com.capgemini.trg.ui;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;

public class FileWriterDemo {

	public static void main(String[] args) {
		writeToFile();

	}

	private static void writeToFile() {
		
		try(
				FileWriter fw=new FileWriter("D:\\Data\\lines.txt");
				BufferedWriter bw=new BufferedWriter(fw);
				PrintWriter pw=new PrintWriter(fw);
				//KBD->isr->br
				InputStreamReader isr=new InputStreamReader(System.in);
				BufferedReader br=new BufferedReader(isr);
				
				
			){
			System.out.println("enter number of lines:");
			int size=Integer.parseInt(br.readLine());
			for(int i=0;i<size;i++){
				System.out.println("Enter Line:"+(i+1));
				//kbd->isr->br->pw->bw->fw
				pw.print(br.readLine());
				pw.println();
			}
			
		}catch(IOException e){
			e.printStackTrace();
			
		}catch(Exception e){
			e.printStackTrace();
			
		}
	}

}
