package com.capgemini.trg.ui;

import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;

import com.capgemini.trg.service.Customer;

public class CustomerDeSerialization {

	public static void main(String[] args) {
		File file=new File("D:\\data\\customers.ser");
		readCustomers(file);

	}

	private static void readCustomers(File file) {
		if(file.exists() && file.canRead()){
			try(
					FileInputStream fis=new FileInputStream(file);
					ObjectInputStream ois=new ObjectInputStream(fis);
					
			){
				while(true){
					Customer customer=(Customer) ois.readObject();
					System.out.println(customer);
				}
				
			}catch(EOFException e){
				System.out.println("End of the file");
				
			}catch(IOException e){
				e.printStackTrace();
				
			}catch(Exception e){
				e.printStackTrace();
				
			}
			
		}else{
			System.out.println("Unable to open the file");
		}
		
	}

}
