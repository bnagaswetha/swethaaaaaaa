package com.capgemini.trg.ui;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class StudentNamesInputStream {

	public static void main(String[] args) {
		FileInputStream fos=null;
		readStudentNames(fos);
		
		
	}

	private static void readStudentNames(FileInputStream fos) {
		int n;
		try{
			fos=new FileInputStream("D:\\Data\\first1.txt");
			
			while(( n=fos.read())!=-1){
				System.out.print((char)n);
			}
		}catch(IOException e){
			e.printStackTrace();
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			try{
				fos.close();
			}catch(IOException e){
				e.printStackTrace();
			}
		}

	}

}
