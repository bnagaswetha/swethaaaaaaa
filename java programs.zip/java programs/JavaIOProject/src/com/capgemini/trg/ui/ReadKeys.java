package com.capgemini.trg.ui;

import java.io.IOException;

public class ReadKeys {

	public static void main(String[] args) {
		StringBuffer sb=new StringBuffer();
		char c;
		try{
			System.out.println("Enter your name and press enter key:");
			while((c=(char)System.in.read())!='\n'){
				sb.append(c);
			}
			System.out.println(sb.length());
			System.out.println(sb.toString());
		}catch(IOException e){
			e.printStackTrace();
		}

	}

}
