package com.capgemini.trg.ui;

import java.io.IOException;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

public class PathsDemo {

	public static void main(String[] args) throws IOException {
		Path path=Paths.get("D:\\Material");
		DirectoryStream<Path> contents=Files.newDirectoryStream(path);
		for(Path content:contents){
			System.out.println(content.getFileName());
		}
		System.out.println(path.getNameCount());
		System.out.println(path.getRoot());
		System.out.println(path.getName(0));
		System.out.println(path.getName(1));
		

	}

}
