package com.capgemini.trg.ui;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.LineNumberReader;

public class FileReaderDemo {

	public static void main(String[] args) {
		readFromFile();

	}

	private static void readFromFile() {
		try(
				FileReader fr=new FileReader("D:\\Data\\lines.txt");
				BufferedReader br=new BufferedReader(fr);
				LineNumberReader lr=new LineNumberReader(br);

				){

			String line;
			while((line=lr.readLine())!=null){
				System.out.println(lr.getLineNumber()+"."+line);
			}
		}

		catch(IOException e){
			e.printStackTrace();

		}catch(Exception e){
			e.printStackTrace();

		}
	}
}


