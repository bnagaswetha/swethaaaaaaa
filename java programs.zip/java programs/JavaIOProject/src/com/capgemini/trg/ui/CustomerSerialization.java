package com.capgemini.trg.ui;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

import com.capgemini.trg.service.Customer;

public class CustomerSerialization {

	public static void main(String[] args) {
		File file=new File("D:\\data\\customers.ser");
		List<Customer> customerList=populateCustomerList();
		writeCustomers(file,customerList);


	}

	private static void writeCustomers(File file, List<Customer> customerList) {
		try(
			FileOutputStream fos=new FileOutputStream(file);
			ObjectOutputStream oos=new ObjectOutputStream(fos);
				
		){
			Iterator<Customer> iterator=customerList.iterator();
			while(iterator.hasNext()){
				Customer customer=iterator.next();
				oos.writeObject(customer);
			}
			oos.flush();
			System.out.println("Customer serialization completed.");
			
		}catch(IOException e){
			e.printStackTrace();
			
		}catch(Exception e){
			e.printStackTrace();
		}
		
	}

	private static List<Customer> populateCustomerList() {
		List<Customer> customerList;
		Customer customers[]=new Customer[5];
		customers[0]=new Customer(1002,"Smith",LocalDate.of(1998,12,7),"Hyderabad",
				573453845L,"smith@gmail.com","smith98");
		customers[1]=new Customer(1001,"Jake",LocalDate.of(1997,2,17),"Chennai",
				5734535L,"jake@gmail.com","jake98");
		customers[2]=new Customer(1004,"Mohan",LocalDate.of(1988,6,9),"Pune",
				57333845L,"Mohan@gmail.com","mohan8");
		customers[3]=new Customer(1003,"Pk",LocalDate.of(1996,7,22),"Delhi",
				873453845L,"pk@gmail.com","pk6");
		customers[4]=new Customer(1005,"Smith1",LocalDate.of(1998,12,4),"Hyderabad",
				573453565L,"smith1@gmail.com","smith198");
		customerList=Arrays.asList(customers);
		return customerList;
	}

}
