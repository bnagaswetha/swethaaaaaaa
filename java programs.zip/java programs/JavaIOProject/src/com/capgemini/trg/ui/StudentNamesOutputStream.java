package com.capgemini.trg.ui;

import java.io.FileOutputStream;
import java.io.IOException;

public class StudentNamesOutputStream {

	public static void main(String[] args) {
		FileOutputStream fos=null;
		writeStudentNames(fos);
		
		
	}

	private static void writeStudentNames(FileOutputStream fos) {
		int n;
		try{
			fos=new FileOutputStream("D:\\Data\\first1.txt",true);
			System.out.println("Enter student names(cntr-z to stop)");
			while((n=System.in.read())!=-1){
				fos.write(n);
			}
		}catch(IOException e){
			e.printStackTrace();
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			try{
				fos.close();
			}catch(IOException e){
				e.printStackTrace();
			}
		}
	}

}
