package com.capgemini.trg.ui;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

public class FileDemo {

	public static void main(String[] args) {
		FileInputStream fis=null;
		try{
			File file=new File("D:\\Data\\first1.txt");
			System.out.println(file.getAbsolutePath());
			System.out.println(file.getPath());
			System.out.println(file.isFile());
			System.out.println(file.canRead());
			System.out.println(file.isDirectory());
			if(file.exists() && file.canRead()){
				fis=new FileInputStream (file);
				System.out.println("File opened in read mode");
			}else{
				System.out.println("Unable to open this file");
			}
			
			
		}catch(IOException e){
			e.printStackTrace();
			
		}catch(Exception e){
			e.printStackTrace();
			
		}

	}

}
