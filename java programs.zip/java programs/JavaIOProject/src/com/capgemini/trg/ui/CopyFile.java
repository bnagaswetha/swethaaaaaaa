package com.capgemini.trg.ui;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class CopyFile {

	public static void main(String[] args) {
		copyStudentnames();

	}

	private static void copyStudentnames() {
		try(
			FileInputStream fis=new FileInputStream ("D:\\Data\\first1.txt");
			//File-->buffer-->file
			BufferedInputStream bis=new BufferedInputStream(fis);
			FileOutputStream fos=new FileOutputStream ("D:\\Data\\first1copy.txt");
			BufferedOutputStream bos=new BufferedOutputStream(fos);
			){
			int n;
			//fis->bis->variable(n)->bos->fos --buffered
			//fis->n->fos --unbuffered
			while((n=bis.read())!=-1){
				bos.write(n);
			}
			System.out.println("File copied  .........");
			
		}catch(IOException e){
			e.printStackTrace();
			
		}
		catch(Exception e){
			e.printStackTrace();
		}
		
	}

}
