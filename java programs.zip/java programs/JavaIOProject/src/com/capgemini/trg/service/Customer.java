package com.capgemini.trg.service;

import java.io.Serializable;
import java.time.LocalDate;

public class Customer implements Serializable,Comparable<Customer> {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Integer customerid;
	private String customerName;
	private LocalDate birthdate;
	private String address;
	private Long mobile;
	private String email;
	private transient String password;
	private String permanentAddress;
	public Customer() {
		super();
	}
	public Customer(Integer customerid, String customerName,
			LocalDate birthdate, String address, Long mobile, String email,
			String password) {
		super();
		this.customerid = customerid;
		this.customerName = customerName;
		this.birthdate = birthdate;
		this.address = address;
		this.mobile = mobile;
		this.email = email;
		this.password = password;
	}
	public Integer getCustomerid() {
		return customerid;
	}
	public void setCustomerid(Integer customerid) {
		this.customerid = customerid;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public LocalDate getBirthdate() {
		return birthdate;
	}
	public void setBirthdate(LocalDate birthdate) {
		this.birthdate = birthdate;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public Long getMobile() {
		return mobile;
	}
	public void setMobile(Long mobile) {
		this.mobile = mobile;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	@Override
	public String toString() {
		return "Customer [customerid=" + customerid + ", customerName="
				+ customerName + ", birthdate=" + birthdate + ", address="
				+ address + ", mobile=" + mobile + ", email=" + email
				+ ", password=" + password + "]";
	}
	/*@Override
	public int compareTo(Object arg0) {
		Customer c=(Customer)arg0;
		if(this.customerid<c.customerid){
			return -1;
		}
		else if(this.customerid>c.customerid){
			return 1;
			
		}
		return 0;
	}*/
	@Override
	public int compareTo(Customer o) {
		
		return this.getCustomerid().compareTo(o.customerid);
	}
	
	
}
