package com.capgemini.trg.ui;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;

import com.capgemini.trg.utility.OracleUtil;

public class NewEmployee {

	public static void main(String[] args) {
		String sql="insert into emp(empno,ename,job,hiredate,sal,comm,deptno) values(?,?,?,?,?,?,?)";
		try(
				Connection connection=OracleUtil.getConnection();
				PreparedStatement preparedStatement=
						connection.prepareStatement(sql);
				
		){
			preparedStatement.setInt(1,1);
			preparedStatement.setString(2, "Sri");
			preparedStatement.setString(3, "Manager");
			String sdate="22/02/2018";
			//convert String to java.util.Date
			DateFormat dateFormat=new SimpleDateFormat("dd/MM/yyyy");
			java.util.Date udate=dateFormat.parse(sdate);
			//convert java.util.date to java.sql.Date
			java.sql.Date hdate=new java.sql.Date(udate.getTime());
			preparedStatement.setDate(4,hdate);
			preparedStatement.setDouble(5, 8000.00);
			preparedStatement.setDouble(6, 500.00);
			preparedStatement.setInt(7,30);
			int n=preparedStatement.executeUpdate();
			if(n>0){
				System.out.println("One Employeee Added");
			}else{
				System.out.println("unable to add employee");
			}
			
			
		}catch(SQLException e){
			e.printStackTrace();
		}catch(Exception e){
			e.printStackTrace();
		}
	}

}
