package com.capgemini.trg.ui;

import java.sql.Connection;

import com.capgemini.trg.utility.OracleConnection;
import com.capgemini.trg.utility.OracleUtil;

public class ConnectionTester {

	public static void main(String[] args) {
		//Connection connection=OracleUtil.getConnection();
		Connection connection=OracleConnection.getConnection();
		if(connection==null){
			System.out.println("unable to connect");
		}else{
			System.out.println("Oracle connected");
		}

	}

}
