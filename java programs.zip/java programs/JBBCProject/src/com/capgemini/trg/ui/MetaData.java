package com.capgemini.trg.ui;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;

import com.capgemini.trg.utility.OracleConnection;

public class MetaData {

	public static void main(String[] args) {
		String sql="select * from emp";
		try(
				Connection connection=OracleConnection.getConnection();
				Statement statement=connection.createStatement();
				
		){
			DatabaseMetaData dbMetaData=connection.getMetaData();
			System.out.println(dbMetaData.supportsSavepoints());
			System.out.println(dbMetaData.getDriverName());
			System.out.println(dbMetaData.getDatabaseProductName());
			System.out.println(dbMetaData.getDatabaseProductVersion());
			System.out.println("-------------------");
			ResultSet resultSet=statement.executeQuery(sql);
			ResultSetMetaData rsMetaData=resultSet.getMetaData();
			System.out.println(rsMetaData.getTableName(1));
			for(int i=1;i<=rsMetaData.getColumnCount();i++){
				System.out.println(rsMetaData.getColumnName(i)+":"+rsMetaData.getColumnTypeName(i));
			}
			
		}catch(SQLException e){
			e.printStackTrace();
			
		}catch(Exception e){
			e.printStackTrace();
		}

	}

}
