package com.capgemini.trg.ui;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

import com.capgemini.trg.utility.OracleConnection;

public class CreateDemo {

	public static void main(String[] args) {
		String sql="create table Account_1(account_number number(6) primary key,name varchar2(20),balance number(10,2))";
		try(
				Connection connection=OracleConnection.getConnection();
				Statement statement=connection.createStatement();
				
		){
			int n=statement.executeUpdate(sql);
			System.out.println(n);
			
		}catch(SQLException e){
			e.printStackTrace();
		}
		

	}

}
