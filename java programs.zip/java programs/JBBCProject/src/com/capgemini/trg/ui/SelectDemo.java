package com.capgemini.trg.ui;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.capgemini.trg.utility.OracleUtil;

public class SelectDemo {

	public static void main(String[] args) throws SQLException {
		Connection connection=null;
		Statement statement=null;
		ResultSet resultSet=null;
		String sql="select empno,ename from emp";
		try{
			connection=OracleUtil.getConnection();
			statement=connection.createStatement();
			resultSet=statement.executeQuery(sql);
			while(resultSet.next()){
				System.out.println(resultSet.getInt("empno")+"\t"+resultSet.getString("ename"));
			}
			
		}catch(SQLException e){
			e.printStackTrace();
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			resultSet.close();
			statement.close();
			connection.close();
		}

	}

}
