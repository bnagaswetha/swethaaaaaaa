package com.capgemini.trg.ui;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.capgemini.trg.utility.OracleUtil;

public class AddEmployee {

	public static void main(String[] args) {
		String sql="{call add_employee(?,?,?,?,?)}";
		/*try(
				Connection connection=OracleUtil.getConnection();
				CallableStatement callableStatement=connection.prepareCall(sql);
				
		){
			callableStatement.setInt(1, 2);
			callableStatement.setString(2, "Sai");
			callableStatement.setString(3, "Developer");
			callableStatement.setDouble(4, 10000.00);
			callableStatement.setInt(5, 10);
			boolean flag=callableStatement.execute();
			if(flag==true){
				System.out.println("Added new employeee");
			}else{
				System.out.println("unable to add employee");
			}
			
			
		}catch(SQLException e){
			e.printStackTrace();
		}catch(Exception e){
			e.printStackTrace();
		}
*/
		try(
				Connection connection=OracleUtil.getConnection();
				PreparedStatement preparedStatement=connection.prepareStatement(sql);
				
		){
			preparedStatement.setInt(1, 3);
			preparedStatement.setString(2, "krishna");
			preparedStatement.setString(3, "Developer");
			preparedStatement.setDouble(4, 10000.00);
			preparedStatement.setInt(5, 10);
			int flag=preparedStatement.executeUpdate();
			
			System.out.println(flag);
			
			
		}catch(SQLException e){
			e.printStackTrace();
		}catch(Exception e){
			e.printStackTrace();
		}

	}

}
