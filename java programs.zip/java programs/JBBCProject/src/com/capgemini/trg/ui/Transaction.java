package com.capgemini.trg.ui;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Savepoint;

import com.capgemini.trg.utility.OracleConnection;

public class Transaction {

	public static void main(String[] args) throws SQLException {

		String sql1 = "update account_1 set balance=balance-25 where account_number=?";
		String sql2 = "update account_1 set balance=balance+25 where account_number=?";
		Savepoint sp1=null;
		Connection connection1=null;
		try(
				Connection connection = OracleConnection.getConnection();
				){
			connection1=connection;
			connection1.setAutoCommit(false);
			sp1=connection1.setSavepoint();
			PreparedStatement preparedStatement1=connection1.prepareStatement(sql1);
			PreparedStatement preparedStatement2=connection1.prepareStatement(sql2);
			preparedStatement1.setInt(1,101);
			preparedStatement2.setInt(1,102);
			preparedStatement1.executeUpdate();
			preparedStatement2.executeUpdate();
			connection1.commit();
			connection1=null;

		}catch(Exception e){
			e.printStackTrace();
			connection1.rollback(sp1);
			connection1=null;
		}




	}

}
