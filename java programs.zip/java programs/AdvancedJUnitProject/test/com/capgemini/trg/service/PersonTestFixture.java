package com.capgemini.trg.service;

import static org.junit.Assert.*;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

public class PersonTestFixture {

	@BeforeClass
	public static void initialize(){
		System.out.println("Initialization...");
	}
	@AfterClass
	public static void cleanup(){
		System.out.println("clean up..");
	}
	@Test
	public void testPerson(){
		assertNotNull(new Person("Robert","King"));
	}
	
}
