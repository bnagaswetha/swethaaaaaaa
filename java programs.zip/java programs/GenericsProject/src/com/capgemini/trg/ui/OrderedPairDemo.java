package com.capgemini.trg.ui;

import com.capgemini.trg.service.OrderedPair;
import com.capgemini.trg.service.Pair;

public class OrderedPairDemo {

	public static void main(String[] args) {
		Pair<Integer,String> myPair1=new OrderedPair<>(1,"Java");
		Pair<String,Long> cityPopulation=new OrderedPair<>("Chennai",60067L);
		System.out.println(myPair1.getKey()+":"+myPair1.getValue());
		System.out.println(cityPopulation.getKey()+":"+cityPopulation.getValue());
		
		OrderedPair<Integer,String> orderedPair=new OrderedPair<>(1,"Java");
		OrderedPair<Integer,String> orderedPair1=orderedPair;
		System.out.println(orderedPair1.getKey()+":"+orderedPair1.getValue());
		//raw type
		OrderedPair orderedPair2=orderedPair;
		System.out.println(orderedPair2.getKey()+":"+orderedPair2.getValue());
		/*
		 * OrderedPair<Integer,string> is generic type while
		 * OrderedPair is raw type.Assigning generic type to raw type is valid to support 
		 * backward compatability.
		 * ArrayList is non-generic not raw type
		 * ArrayList<T> is generic type
		 */
	}

}
