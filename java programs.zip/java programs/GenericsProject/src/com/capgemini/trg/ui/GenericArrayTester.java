package com.capgemini.trg.ui;

import com.capgemini.trg.service.Utility;

public class GenericArrayTester {

	public static void main(String[] args) {

		Integer intArray[]={10,20,22};
		Double doubleArray[]={2.3,8.3,4.2};
		String stringArray[]={"Java SE","JAVA"};
		Utility.printArray(intArray);
		Utility.printArray(doubleArray);
		Utility.printArray(stringArray);
	}

}
