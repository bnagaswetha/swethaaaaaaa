package com.capgemini.trg.ui;

import com.capgemini.trg.service.OrderedPair;
import com.capgemini.trg.service.Utility;

public class CompareDemo {

	public static void main(String[] args) {
		
		OrderedPair<Integer,String> op1=new OrderedPair<>(1,"apple");
		OrderedPair<Integer,String> op2=new OrderedPair<>(1,"appl");
		Boolean status=Utility.compare(op1,op2);
		System.out.println(status);
		
	}

}
