package com.capgemini.trg.ui;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import com.capgemini.trg.service.Person;
import com.capgemini.trg.service.Professor;
import com.capgemini.trg.service.Student;

public class CovarientTester {

	public static void main(String[] args) {
		Person persons[]=new Person[4];
		Student students[]=new Student[4];
		List<Person> personList=new ArrayList<>();
		List<Student> studentList=new ArrayList<>();
		Student s=null;
		Person p=s;
		/*
		 * 
		 */
		persons=students;
		persons[0]=new Student();
		//persons[1]=new Professor();
		//personList=studentsList;
		/*
		 * Student is subclass of person but
		 * List<Student>is not subclass of List<Person>
		 */

		List<String> namesList=new ArrayList<>();
		//List<String> is not sub class of List<Object.
		//List<Object> objectList=namesList;
		namesList.add("Java");
		namesList.add("Java EE");
		printList(namesList);
		List<Integer> intList=Arrays.asList(10,20,30);
		List<Double> doubleList=Arrays.asList(2.3,3.4,5.6);
		printNumericList(intList);
		printSuperTypeList(intList);
	}



	private static void printList(List<?> namesList) {
		for(Object o:namesList){
			System.out.println(o);

		}		
	}
	//upper bound wild character
	/*
	 * This method can receive List of Number or any of its
	 * sub types. i.e,it can receive List<Number>,List<Integer>,List<Float>...
	 */
	private static void printNumericList(List<? extends Number> myList) {

		for(Number m:myList){
			System.out.println(m);
		}

	}
	//Lower bound wild character
	/*
	 * This method can receive List<Integer> and its super types
	 * List<NUmber>,List<Object>
	 */
	private static void printSuperTypeList(List<? super Integer> myList) {

		for(Object m:myList){
			System.out.println(m);
		}

	}

}
