package com.capgemini.trg.service;

//Generic Interface
public interface Pair<K,V> {
	public K getKey();
	public V getValue();

}
