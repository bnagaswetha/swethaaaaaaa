package com.capgemini.trg.service;

public class Student extends Person {

}
