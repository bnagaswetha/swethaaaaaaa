package com.capgemini.trg.service;

public class Person {

}
