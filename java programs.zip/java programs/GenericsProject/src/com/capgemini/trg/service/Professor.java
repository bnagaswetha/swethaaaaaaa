package com.capgemini.trg.service;

public class Professor extends Person{

}
