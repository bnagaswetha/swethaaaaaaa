package com.capgemini.trg.service;

public class Utility {
	
	//generic method
	public static <K,V> Boolean compare(OrderedPair<K,V> p1,OrderedPair<K,V> p2){
		if(p1.getKey().equals(p2.getKey())&&p1.getValue().equals(p2.getValue())){
			return true;
		}
		return false;
	}
	//generic method
	public static <T> void printArray(T inputArray[]){
		for(T t:inputArray){
			System.out.println(t);
		}
	}

}
