package com.capgemini.hbms.service;

import java.time.LocalDate;
import java.util.List;

import com.capgemini.hbms.bean.BookingDetails;
import com.capgemini.hbms.exception.HBMSException;

public interface IBookingService {
	public Integer addBookingDetails(BookingDetails bookingDetails) throws HBMSException;

	public BookingDetails getBookingDetails(String email) throws HBMSException;

	public List<BookingDetails> getBookingDetails(int hotel_id) throws HBMSException;

	public List<BookingDetails> getBookingDetails(LocalDate fdate) throws HBMSException;

}
