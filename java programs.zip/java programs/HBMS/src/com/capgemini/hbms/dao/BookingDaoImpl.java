package com.capgemini.hbms.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.capgemini.hbms.bean.BookingDetails;
import com.capgemini.hbms.exception.HBMSException;
import com.capgemini.hbms.util.DBConnection;

public class BookingDaoImpl implements IBookingDao{

	final static Logger bookinglogger=Logger.getLogger(BookingDaoImpl.class);

	@Override
	public Integer addBookingDetails(BookingDetails bookingDetails) throws HBMSException {
		try(Connection connection=DBConnection.getConnection();	
				PreparedStatement preparestatement=connection.prepareStatement(QueryMapper.ADD_BOOKING_DETAILS);
				PreparedStatement preparestatement1=connection.prepareStatement(QueryMapper.GET_BOOKING_ID);
				PreparedStatement preparestatement2=connection.prepareStatement(QueryMapper.CHANGE_AVAILABILITY);
				){

			preparestatement.setInt(1,bookingDetails.getRoom_id());
			preparestatement.setInt(2,bookingDetails.getUser_id());
			preparestatement.setDate(3,Date.valueOf(bookingDetails.getBooked_from()));
			preparestatement.setDate(4,Date.valueOf(bookingDetails.getBooked_to()));
			preparestatement.setInt(5,bookingDetails.getNo_of_adults());
			preparestatement.setInt(6,bookingDetails.getNo_of_children());
			preparestatement.setDouble(7,bookingDetails.getAmount());

			preparestatement1.setInt(1, bookingDetails.getUser_id());
			preparestatement1.setInt(2, bookingDetails.getRoom_id());
			preparestatement2.setString(1, "no");
			preparestatement2.setInt(2, bookingDetails.getRoom_id());

			int i=preparestatement.executeUpdate();
			if(i>0){
				int i1=preparestatement2.executeUpdate();
				ResultSet resultSet=preparestatement1.executeQuery();
				if(resultSet.next())
					return resultSet.getInt(1);
			}else{
				System.out.println("Unable to book");
			}
		}catch(NullPointerException e){
			
		}
		catch (SQLException e) {
			bookinglogger.error("unable to book");		
			//e.printStackTrace();
		}
		return 0;

	}

	@Override
	public BookingDetails getBookingDetails(String email) throws HBMSException {
		try(Connection connection=DBConnection.getConnection();	
				PreparedStatement preparestatement=connection.prepareStatement(QueryMapper.GET_BOOKING_DETAILS);
				PreparedStatement preparestatement1=connection.prepareStatement(QueryMapper.GET_USER_ID);

				){



			preparestatement1.setString(1,email);


			ResultSet rs=preparestatement1.executeQuery();
			if(rs.next()){
				int user_id=rs.getInt(1);
				preparestatement.setInt(1,user_id);
				ResultSet rs1=preparestatement.executeQuery();
				if(rs1.next()){
					BookingDetails bookingDetails=new BookingDetails();
					bookingDetails.setBooking_id(rs1.getInt("booking_id"));
					bookingDetails.setRoom_id(rs1.getInt("room_id"));
					bookingDetails.setUser_id(rs1.getInt("user_id"));
					bookingDetails.setBooked_from(rs1.getDate("booked_from").toLocalDate());
					bookingDetails.setBooked_to(rs1.getDate("booked_to").toLocalDate());
					bookingDetails.setNo_of_adults(rs1.getInt("no_of_adults"));
					bookingDetails.setNo_of_children(rs1.getInt("no_of_children"));
					bookingDetails.setAmount(rs1.getDouble("amount"));
					return bookingDetails;
				}

			}else{
				System.out.println("Unable to print booking details");
			}
		} catch (SQLException e) {
			bookinglogger.error("unable to print the booking details");
			//e.printStackTrace();
		}
		return null;


	}

	@Override
	public List<BookingDetails> getBookingDetails(int hotel_id)
			throws HBMSException {
		try(Connection connection=DBConnection.getConnection();	
				PreparedStatement preparestatement=connection.prepareStatement(QueryMapper.GET_BOOKING_DETAILS_HOTEL);


				){
			preparestatement.setInt(1,hotel_id );

			ResultSet rs1=preparestatement.executeQuery();
			List<BookingDetails> list=new ArrayList<>();
			while(rs1.next()){

				BookingDetails bookingDetails=new BookingDetails();
				bookingDetails.setBooking_id(rs1.getInt("booking_id"));
				bookingDetails.setRoom_id(rs1.getInt("room_id"));
				bookingDetails.setUser_id(rs1.getInt("user_id"));
				bookingDetails.setBooked_from(rs1.getDate("booked_from").toLocalDate());
				bookingDetails.setBooked_to(rs1.getDate("booked_to").toLocalDate());
				bookingDetails.setNo_of_adults(rs1.getInt("no_of_adults"));
				bookingDetails.setNo_of_children(rs1.getInt("no_of_children"));
				bookingDetails.setAmount(rs1.getDouble("amount"));
				list.add(bookingDetails);
			}
			return list;
		} catch (SQLException e) {
			bookinglogger.error("unable to get booking details");
			//e.printStackTrace();
		}
		return null;

	}

	@Override
	public List<BookingDetails> getBookingDetails(LocalDate fdate)
			throws HBMSException {
		try(Connection connection=DBConnection.getConnection();	
				PreparedStatement preparestatement=connection.prepareStatement(QueryMapper.GET_BOOKING_DETAILS_DATE);


				){
			preparestatement.setDate(1,Date.valueOf(fdate));

			ResultSet rs1=preparestatement.executeQuery();
			List<BookingDetails> list=new ArrayList<>();
			while(rs1.next()){

				BookingDetails bookingDetails=new BookingDetails();
				bookingDetails.setBooking_id(rs1.getInt("booking_id"));
				bookingDetails.setRoom_id(rs1.getInt("room_id"));
				bookingDetails.setUser_id(rs1.getInt("user_id"));
				bookingDetails.setBooked_from(rs1.getDate("booked_from").toLocalDate());
				bookingDetails.setBooked_to(rs1.getDate("booked_to").toLocalDate());
				bookingDetails.setNo_of_adults(rs1.getInt("no_of_adults"));
				bookingDetails.setNo_of_children(rs1.getInt("no_of_children"));
				bookingDetails.setAmount(rs1.getDouble("amount"));
				list.add(bookingDetails);
				bookinglogger.info("succesfully fetched booking details");  

			}
			return list;
		} catch (SQLException e) {
			bookinglogger.error("Unable to get booking details based on date");
			//e.printStackTrace();
		}
		return null;

	}

}
