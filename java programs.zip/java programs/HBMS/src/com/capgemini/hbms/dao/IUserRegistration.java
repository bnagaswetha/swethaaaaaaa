package com.capgemini.hbms.dao;

import com.capgemini.hbms.bean.Users;
import com.capgemini.hbms.exception.HBMSException;

public interface IUserRegistration {
	public boolean registerUser(Users user) throws HBMSException;

}
