package com.capgemini.hbms.dao;

import java.util.List;

import com.capgemini.hbms.bean.Hotel;
import com.capgemini.hbms.exception.HBMSException;

public interface IHotelDao {

	Boolean addHotelDetails(Hotel hotel) throws HBMSException;

	void deleteHotelDetails(Integer hotelId1) throws HBMSException;

	List<Hotel> displayHotelDetails() throws HBMSException;

	Boolean updatePrice(Double price, Integer hotelId2) throws HBMSException;

	void updateDescrption(String string, Integer hotelId2) throws HBMSException;

	boolean hotelExist(Integer hotelId2) throws HBMSException;

}
