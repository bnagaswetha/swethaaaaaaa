package com.capgemini.trg.ui;

import com.capgemini.trg.service.Greeting;
import com.capgemini.trg.service.IGreeting;

public class InterfaceDemo {

	public static void main(String[] args) {
		IGreeting greet=new Greeting();
		System.out.println(greet.getMessage());
	}

}
