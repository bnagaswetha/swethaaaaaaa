package com.capgemini.trg.ui;

import com.capgemini.trg.service.Interface1;
import com.capgemini.trg.service.Interface2;
import com.capgemini.trg.service.MyClass;

public class MyClassTester {

	public static void main(String[] args) {
		MyClass myClass=new MyClass();
		myClass.show();//abstract method
		myClass.print();//default method
		Interface1.greetings();//static method of Interface
		Interface2.greetings();
		myClass.print();
	}

}
