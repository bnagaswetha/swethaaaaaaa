package com.capgemini.trg.service;

public class MyClass implements Interface1,Interface2{

	@Override
	public void show() {
		System.out.println("Hii overriding abstract method of Interface");
	}
	//print() is existing in both interface1 inteface2
	public void print(){
		System.out.println("re-defining default method,print() to handle diamond issue");
	}

}
