package com.capgemini.trg.service;

public class Greeting implements IGreeting {

	@Override
	public String getMessage() {
		return "Hello";
	}
	

}
