package com.capgemini.trg.service;

public interface Interface1 {
	public default void print(){
		System.out.println("print() method of Interface1");
	}
	public static void greetings(){
		System.out.println("Greetings from Interface1");
	}
	abstract public void show();

}
