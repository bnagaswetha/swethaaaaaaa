package com.capgemini.trg.service;
@FunctionalInterface
public interface IGreeting {
	
	public String getMessage();

}
