package com.capgemini.trg.service;

public interface Interface2 {
	public default void print(){
		System.out.println("print() method of Interface2");
	}
	public static void greetings(){
		System.out.println("Greetings from Interface2");
	}
	abstract public void show();


}
